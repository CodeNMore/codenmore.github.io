Sheep Shift was made in under 12 hours for Ludum Dare #35 by CodeNMore
The music may not play properly, so press "M" to mute if needed!
Source code can be found here: https://github.com/CodeNMore/LudumDare35