package competition.codenmore.ld29.objects;

import java.awt.Rectangle;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.sfx.Sound;

public class BombMini extends Object {
	
	public BombMini(int xo, int yo){
		this.xo = xo;
		this.yo = yo;
	}

	public void tick() {
		if(collisionPlayer())
			active = false;
	}
	
	public boolean collisionPlayer(){
		if(getBounds().intersects(GameState.getPlayer().getBounds())){
			GameState.getPlayer().tnt++;
			Sound.collectClip.play();
			
			return true;
		}
		
		return false;
	}
	
	public Rectangle getBounds(){
		return new Rectangle(xo, yo, Game.TILESIZE, Game.TILESIZE);
	}

	public void render(Screen screen) {
		if(active)
			screen.render(ImageManager.tntMini, xo - GameState.getPlayer().getXOffset(), yo - GameState.getPlayer().getYOffset());
	}

}
