package competition.codenmore.ld29.objects;

import java.awt.Rectangle;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.entities.Entity;
import competition.codenmore.ld29.entities.EntityManager;
import competition.codenmore.ld29.entities.Ghost;
import competition.codenmore.ld29.gfx.Animation;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.sfx.Sound;

public class Bomb extends Object {
	
	private int steadyTimer = 0, steadyTime = 120;
	private Animation animation;
	
	public Bomb(int xo, int yo){
		this.xo = xo;
		this.yo = yo;
		animation = new Animation(ImageManager.tnt1, ImageManager.tnt2, 20);
	}

	public void tick() {
		steadyTimer++;
		if(steadyTimer > steadyTime){
			active = false;
			
			int xt = xo / Game.TILESIZE;
			int yt = yo / Game.TILESIZE;
			
			LevelManager.getCurrentLevel().setTile(xt - 1, yt - 1, 0);
			LevelManager.getCurrentLevel().setTile(xt, yt - 1, 0);
			LevelManager.getCurrentLevel().setTile(xt + 1, yt - 1, 0);
			
			LevelManager.getCurrentLevel().setTile(xt - 1, yt, 0);
			LevelManager.getCurrentLevel().setTile(xt, yt, 0);
			LevelManager.getCurrentLevel().setTile(xt + 1, yt, 0);
			
			LevelManager.getCurrentLevel().setTile(xt - 1, yt + 1, 0);
			LevelManager.getCurrentLevel().setTile(xt, yt + 1, 0);
			LevelManager.getCurrentLevel().setTile(xt + 1, yt + 1, 0);
			
			collisionWithEnemy();
			
			Sound.explosionClip.play();
		}
		
		animation.tick();
	}
	
	public void collisionWithEnemy(){
		for(Entity e : EntityManager.entities){
			if(e instanceof Ghost){
				if(getBounds().intersects(((Ghost) e).getBounds())){
					e.die();
				}
			}
		}
	}

	public Rectangle getBounds(){
		return new Rectangle(xo - Game.TILESIZE, yo - Game.TILESIZE, Game.TILESIZE * 3, Game.TILESIZE * 3);
	}
	
	public void render(Screen screen) {
		if(active)
			animation.render(screen, xo - GameState.getPlayer().getXOffset(), yo - GameState.getPlayer().getYOffset());
	}

}