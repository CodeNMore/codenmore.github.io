package competition.codenmore.ld29.tiles;

import competition.codenmore.ld29.gfx.Screen;

public class Tile {
	
	public static Tile backTile = new BackTile();
	public static Tile wallTile = new WallTile();
	
	public void render(Screen screen, int x, int y){
		
	}
	
	public boolean isSolid(){
		return false;
	}
	
}
