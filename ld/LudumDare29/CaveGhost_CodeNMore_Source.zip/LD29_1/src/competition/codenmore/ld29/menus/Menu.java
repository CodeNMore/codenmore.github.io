package competition.codenmore.ld29.menus;

import competition.codenmore.ld29.gfx.Screen;

public abstract class Menu {

	public abstract void tick();
	
	public abstract void render(Screen screen);
	
}
