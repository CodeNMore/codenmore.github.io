package competition.codenmore.ld29.levels;

import java.util.Random;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.entities.Ghost;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.objects.BombMini;
import competition.codenmore.ld29.objects.Scrap;
import competition.codenmore.ld29.tiles.Tile;

public class Level {

	public static final int BACKTILE = 0, WALLTILE = 1, TILESIZE = Game.TILESIZE;
	private Random r = new Random();
	public int mapWidth, mapHeight;
	private int[] tiles;
	
	public Level(int mapWidth, int mapHeight, int enemies, int scrap, int bombs){
		this.mapWidth = mapWidth;
		this.mapHeight = mapHeight;
		tiles = new int[mapWidth * mapHeight];
		generateLevel(enemies, scrap, bombs);
	}
	
	public void generateLevel(int enemies, int scrap, int bombs){
		//Initialize to backtiles
		for(int i = 0;i < tiles.length;i++)
			tiles[i] = BACKTILE;
		
		//Randomly generate walls TEMP
		for(int i = 0;i < tiles.length;i++){
			if(r.nextInt(90) < 25)
				tiles[i] = WALLTILE;
		}
		
		//SPAWN POSITION
		tiles[0] = BACKTILE;
		tiles[1] = BACKTILE;
		tiles[2] = BACKTILE;
		tiles[3] = BACKTILE;
		tiles[4] = BACKTILE;
		tiles[5] = BACKTILE;
		tiles[6] = BACKTILE;
		GameState.getPlayer().setXOffset(-GameState.getPlayer().getX());
		GameState.getPlayer().setYOffset(-GameState.getPlayer().getY());
		
		//Enemies
		for(int i = 0;i < enemies;i++){
			int t = r.nextInt(4) + 1;
			if(t == 1) t = 2;
			Ghost g = new Ghost(t);
			g.setXOffset(r.nextInt(mapWidth * TILESIZE));
			g.setYOffset(r.nextInt(mapHeight * TILESIZE));
			GameState.entityManager.addEntity(g);
		}
		
		//Scrap
		for(int i = 0;i < scrap;i++){
			int tx = r.nextInt(mapWidth);
			int ty = r.nextInt(mapHeight);
			if(!getTile(tx, ty).isSolid()){
				Scrap s = new Scrap(tx * TILESIZE, ty * TILESIZE);
				if(!getTile(tx - 1, ty).isSolid() || !getTile(tx + 1, ty).isSolid() || !getTile(tx, ty - 1).isSolid() || !getTile(tx, ty + 1).isSolid())
					GameState.objects.add(s);
				else
					i--;
			}else{
				i--;
			}
		}
		
		//Bombs
		for(int i = 0;i < bombs;i++){
			int tx = r.nextInt(mapWidth);
			int ty = r.nextInt(mapHeight);
			if(!getTile(tx, ty).isSolid()){
				BombMini b = new BombMini(tx * TILESIZE, ty * TILESIZE);
				if(!getTile(tx - 1, ty).isSolid() || !getTile(tx + 1, ty).isSolid() || !getTile(tx, ty - 1).isSolid() || !getTile(tx, ty + 1).isSolid())
					GameState.objects.add(b);
				else
					i--;
			}else{
				i--;
			}
		}
	}
	
	public void render(Screen screen){
		int xo = GameState.getPlayer().getXOffset();
		int yo = GameState.getPlayer().getYOffset();
		
		int x0 = Math.max(xo / TILESIZE, 0);
		int y0 = Math.max(yo / TILESIZE, 0);
		int x1 = Math.min((xo + Game.WIDTH) / TILESIZE + 1, mapWidth);
		int y1 = Math.min((yo + Game.HEIGHT) / TILESIZE + 1, mapHeight);
		
		for(int y = y0;y < y1;y++){
			for(int x = x0;x < x1;x++){
				getTile(x, y).render(screen, x * TILESIZE - xo, y * TILESIZE - yo);
			}
		}
	}
	
	public Tile getTile(int x, int y){
		if(x > mapWidth || y > mapHeight || x < 0 || y < 0)
			return Tile.backTile;
		if(x + y * mapWidth > tiles.length)
			return Tile.backTile;
		
		if(tiles[x + y * mapWidth] == WALLTILE) return Tile.wallTile;
		
		return Tile.backTile;
	}
	
	public void setTile(int x, int y, int t){
		if(x < 0 || y < 0 || x > mapWidth || y > mapHeight) return;
		
		tiles[x + y * mapWidth] = t;
	}
	
}