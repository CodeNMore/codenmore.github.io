package competition.codenmore.ld29.entities;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.controls.KeyManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.sfx.Sound;

public abstract class Entity {
	
	protected final int UP = 0, RIGHT = 1, DOWN = 2, LEFT = 3;
	protected int dir = DOWN;
	protected int x, y, xo, yo, vx, vy;
	public int health = 1;
	protected float velocity = 2f;
	protected KeyManager km = Game.getKeyManager();
	public boolean active = true;
	
	public void move(int vx, int vy){
		if(!collision(vx, 0)){
			xo += vx;
		}
		
		if(!collision(0, vy)){
			yo += vy;
		}
	}
	
	public void moveNoCollision(int vx, int vy){
		xo += vx;
		yo += vy;
	}
	
	public void die(){
		active = false;
	}
	
	public void hurt(int amount){
		health -= amount;
		if(health <= 0){
			die();
		}
		Sound.hurtClip.play();
	}
	
	public boolean collision(int vx, int vy){
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x) / Game.TILESIZE, (yo + vy + y) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + Game.TILESIZE - 1) / Game.TILESIZE, (yo + vy + y) / Game.TILESIZE).isSolid()) return true;
		
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x) / Game.TILESIZE, (yo + vy + y + Game.TILESIZE - 1) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + Game.TILESIZE - 1) / Game.TILESIZE, (yo + vy + y + Game.TILESIZE - 1) / Game.TILESIZE).isSolid()) return true;
		
		return false;
	}
	
	public abstract void tick();
	
	public abstract void render(Screen screen);
	
	public int getXOffset(){
		return xo;
	}
	
	public int getYOffset(){
		return yo;
	}
	
	public void setXOffset(int xo){
		this.xo = xo;
	}
	
	public void setYOffset(int yo){
		this.yo = yo;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
}
