package competition.codenmore.ld29.entities;

import java.awt.Rectangle;
import java.util.Random;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.gfx.Animation;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.menus.GameState;

public class Ghost extends Entity {

	private Animation animation;
	private Random r;
	private boolean wandering = false, canMove = true;
	private int toMoveX = 0, toMoveY = 0, wanderTimer = 0, wanderTime = 120, canMoveTimer = 0, canMoveHold = 70;
	
	public Ghost(int health){
		this.health = health;
		velocity = 1.8f;
		r = new Random();
		animation = new Animation(ImageManager.ghost1, ImageManager.ghost2, 15);
	}
	
	public void tick() {
		if(canMove){
			if(!hasPlayerInSight()){
				wander();
			}else{
				wandering = false;
				toPlayer();
			}
		}else{
			canMoveTimer++;
			if(canMoveTimer > canMoveHold){
				canMoveTimer = 0;
				canMove = true;
			}
		}
		
		if(xo < 0)
			xo = 0;
		if(xo > LevelManager.getCurrentLevel().mapWidth * Game.TILESIZE - Game.TILESIZE)
			xo = LevelManager.getCurrentLevel().mapWidth * Game.TILESIZE - Game.TILESIZE;
		if(yo < 0)
			yo = 0;
		if(yo > LevelManager.getCurrentLevel().mapHeight * Game.TILESIZE - Game.TILESIZE)
			yo = LevelManager.getCurrentLevel().mapHeight * Game.TILESIZE - Game.TILESIZE;
		
		animation.tick();
		
		checkPlayerCollision();
	}
	
	public void checkPlayerCollision(){
		if(canMove && getBounds().intersects(GameState.getPlayer().getBounds())){
			canMove = false;
			GameState.getPlayer().hurt(1);
		}
	}
	
	public Rectangle getBounds(){
		return new Rectangle(xo, yo, Game.TILESIZE, Game.TILESIZE);
	}

	public void render(Screen screen) {
		animation.render(screen, xo - GameState.getPlayer().getXOffset(), yo - GameState.getPlayer().getYOffset());
	}
	
	public boolean hasPlayerInSight(){
		int pxo = GameState.getPlayer().getXOffset() + GameState.getPlayer().getX();
		int pyo = GameState.getPlayer().getYOffset() + GameState.getPlayer().getY();
		
		if(pxo - xo < Game.WIDTH / 2 && xo - pxo < Game.WIDTH / 2){
			if(pyo - yo < Game.HEIGHT / 2 && yo - pyo < Game.HEIGHT / 2){
				return true;
			}
		}
		
		return false;
	}
	
	public void die(){
		active = false;
		GameState.getPlayer().score++;
	}
	
	public void toPlayer(){
		int tx = 0, ty = 0;
		
		int pxo = GameState.getPlayer().getXOffset() + GameState.getPlayer().getX();
		int pyo = GameState.getPlayer().getYOffset() + GameState.getPlayer().getY();
		
		if(xo < pxo)
			tx = (int) velocity;
		if(xo > pxo)
			tx = (int) -velocity;
		if(yo < pyo)
			ty = (int) velocity;
		if(yo > pyo)
			ty = (int) -velocity;
		
		moveNoCollision(tx, ty);
	}
	
	public void wander(){
		if(wandering){
			wanderTimer++;
			if(wanderTimer > wanderTime){
				wanderTimer = 0;
				wandering = false;
			}
			
			moveNoCollision(toMoveX, toMoveY);
			
		}else{
			wandering = true;
			toMoveX = 0;
			toMoveY = 0;
			int d = r.nextInt(3);
			int amt = r.nextInt((int) velocity);
			boolean isNeg = r.nextBoolean();
			if(d == 0){//X
				if(isNeg)
					toMoveX = -amt;
				else
					toMoveX = amt;
			}else if(d == 1){//Y
				if(isNeg)
					toMoveY = -amt;
				else
					toMoveY = amt;
			}else{//Both
				if(isNeg){
					toMoveX = -amt;
					toMoveY = -amt;
				}else{
					toMoveX = amt;
					toMoveY = amt;
				}
			}
		}
	}

}