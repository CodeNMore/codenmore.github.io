package competition.codenmore.ld29.gfx;

public class Color {

	public static final int
			BLACK = 0xFF000000,
			WHITE = 0xFFFFFFFF,
			GREEN = 0xFF00FF00,
			GRAY = 0xFF404040,
			LIGHTGRAY = 0xFFA0A0A0;
	
}
