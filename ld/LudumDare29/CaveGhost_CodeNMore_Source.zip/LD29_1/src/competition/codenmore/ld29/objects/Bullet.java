package competition.codenmore.ld29.objects;

import java.awt.Rectangle;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.entities.Entity;
import competition.codenmore.ld29.entities.EntityManager;
import competition.codenmore.ld29.entities.Ghost;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.sfx.Sound;

public class Bullet extends Object{

	public Bullet(int xo, int yo, int vx, int vy){
		this.vx = vx;
		this.vy = vy;
		this.xo = xo;
		this.yo = yo;
	}
	
	public void tick() {
		if(active){
			xo += vx;
			yo += vy;
			
			collisionWithEnemy();
			
			if(collisionWithWall()){
				active = false;
			}
			
			checkEnd();
		}
	}
	
	public void checkEnd(){
		if((xo < GameState.getPlayer().getXOffset() || xo > GameState.getPlayer().getXOffset() + Game.WIDTH) && (yo < GameState.getPlayer().getYOffset() || yo < GameState.getPlayer().getYOffset() + Game.HEIGHT)){
			active = false;
		}
	}
	
	public boolean collisionWithWall(){
		if(LevelManager.getCurrentLevel().getTile((xo + 9) / Game.TILESIZE, (yo + 9) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + Game.TILESIZE - 10) / Game.TILESIZE, (yo + 9) / Game.TILESIZE).isSolid()) return true;
		
		if(LevelManager.getCurrentLevel().getTile((xo + 9) / Game.TILESIZE, (yo +  Game.TILESIZE - 1) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + Game.TILESIZE - 10) / Game.TILESIZE, (yo + Game.TILESIZE - 10) / Game.TILESIZE).isSolid()) return true;
		
		return false;
	}
	
	public void collisionWithEnemy(){
		for(Entity e : EntityManager.entities){
			if(e instanceof Ghost){
				if(getBounds().intersects(((Ghost) e).getBounds())){
					e.hurt(1);
					active = false;
					Sound.hurtClip.play();
					return;
				}
			}
		}
	}
	
	public Rectangle getBounds(){
		return new Rectangle(xo + 9, yo + 9, 13, 13);
	}

	public void render(Screen screen) {
		if(active)
			screen.render(ImageManager.bullet, xo - GameState.getPlayer().getXOffset(), yo - GameState.getPlayer().getYOffset());
	}

}
