package competition.codenmore.ld29.levels;

public class LevelManager {
	
	private static Level currentLevel;
	
	public static void setCurrentLevel(Level newLevel){
		currentLevel = newLevel;
	}
	
	public static Level getCurrentLevel(){
		return currentLevel;
	}
	
}
