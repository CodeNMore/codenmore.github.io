package competition.codenmore.ld29.sfx;

import java.applet.Applet;
import java.applet.AudioClip;

public class Sound {
	
	public static AudioClip shootClip, hurtClip, explosionClip, collectClip;

	public Sound(){
		shootClip = Applet.newAudioClip(getClass().getResource("/sfx/shoot.wav"));
		collectClip = Applet.newAudioClip(getClass().getResource("/sfx/collect.wav"));
		hurtClip = Applet.newAudioClip(getClass().getResource("/sfx/hurt.wav"));
		explosionClip = Applet.newAudioClip(getClass().getResource("/sfx/explosion.wav"));
	}
	
}