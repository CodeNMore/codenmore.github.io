package competition.codenmore.ld29.tiles;

import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;

public class WallTile extends Tile {

	public void render(Screen screen, int x, int y){
		screen.render(ImageManager.wallTile, x, y);
	}
	
	public boolean isSolid(){
		return true;
	}
	
}
