package competition.codenmore.ld29.objects;

import java.awt.Rectangle;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.gfx.Screen;

public abstract class Object {
	
	protected int xo, yo, vx, vy;
	public boolean active = true;
	
	public abstract void tick();
	
	public abstract void render(Screen screen);
	
	public Rectangle getBounds(){
		return new Rectangle(xo, yo, Game.TILESIZE, Game.TILESIZE);
	}

}
