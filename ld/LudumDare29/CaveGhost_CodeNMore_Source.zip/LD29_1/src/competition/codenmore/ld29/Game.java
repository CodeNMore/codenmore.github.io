package competition.codenmore.ld29;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

import competition.codenmore.ld29.controls.KeyManager;
import competition.codenmore.ld29.gfx.Color;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.menus.MainMenu;
import competition.codenmore.ld29.menus.MenuManager;
import competition.codenmore.ld29.sfx.Sound;

public class Game extends Canvas implements Runnable{
	
	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 600, HEIGHT = 500, TILESIZE = 32;
	public static final String TITLE = "CodeNMore - LD29 - Beneath the Surface - Cave Ghost";
	public static final Dimension DIM = new Dimension(WIDTH, HEIGHT);
	private static boolean running = false;
	private Thread thread;
	
	private Screen screen;
	
	private static KeyManager km;
	
	public void init(){
		new Sound();
		Sound.collectClip.play();
		screen = new Screen(WIDTH, HEIGHT);
		km = new KeyManager();
		this.addKeyListener(km);
		MenuManager.setCurrentMenu(new MainMenu());
	}
	
	public void tick(){
		if(MenuManager.getCurrentMenu() != null)
			MenuManager.getCurrentMenu().tick();
	}
	
	public void render(){
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null){
			createBufferStrategy(3);
			requestFocus();
			return;
		}
		Graphics g = bs.getDrawGraphics();
		//RENDER
		
		screen.clear(Color.LIGHTGRAY);
		if(MenuManager.getCurrentMenu() != null)
			MenuManager.getCurrentMenu().render(screen);
		
		//END RENDER
		g.drawImage(screen.image, 0, 0, WIDTH, HEIGHT, null);
		bs.show();
		g.dispose();
	}
	
	public static KeyManager getKeyManager(){
		return km;
	}

	public void run(){
		init();
		long lastTime = System.nanoTime();
		final double amountOfTicks = 60D;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		
		while(running){
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if(delta >= 1){
				tick();
				delta--;
			}
			render();
		}
		stop();
	}
	
	public synchronized void start(){
		if(running)
			return;
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public synchronized void stop(){
		if(!running)
			return;
		running = false;
	}
	
	public static void main(String[] args){
		Game game = new Game();
		game.setPreferredSize(DIM);
		game.setMaximumSize(DIM);
		game.setMinimumSize(DIM);
		
		JFrame frame = new JFrame(TITLE);
		frame.setSize(DIM);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.add(game);
		frame.setVisible(true);
		
		game.start();
	}
	
}