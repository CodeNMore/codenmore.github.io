package competition.codenmore.ld29.entities;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.gfx.Animation;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.menus.GameOverMenu;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.menus.MenuManager;
import competition.codenmore.ld29.objects.Bomb;
import competition.codenmore.ld29.objects.Bullet;
import competition.codenmore.ld29.sfx.Sound;

public class Player extends Entity{
	
	private Animation upAnimation, downAnimation, leftAnimation, rightAnimation;
	private boolean canShoot = true, canPlaceBomb = true;
	private int shootTimer = 0, canShootTime = 23, bombTimer = 0, canPlaceTime = 20;
	public int score = 0, scrap = 0, winScrap = 10, tnt = 2;
	
	public Player(int health){
		this.health = health;
		x = Game.WIDTH / 2 - 16;
		y = Game.HEIGHT / 2 - 32;
		
		upAnimation = new Animation(ImageManager.playerUp, ImageManager.playerUp2, 15);
		downAnimation = new Animation(ImageManager.playerDown, ImageManager.playerDown2, 15);
		leftAnimation = new Animation(ImageManager.playerLeft, ImageManager.playerLeft2, 15);
		rightAnimation = new Animation(ImageManager.playerRight, ImageManager.playerRight2, 15);
	}
	
	public void tick() {
		vx = 0;
		vy = 0;
		if(km.keys[KeyEvent.VK_A] || km.keys[KeyEvent.VK_LEFT]){
			vx -= velocity;
			dir = LEFT;
		}else if(km.keys[KeyEvent.VK_D] || km.keys[KeyEvent.VK_RIGHT]){
			vx += velocity;
			dir = RIGHT;
		}
		if(km.keys[KeyEvent.VK_W] || km.keys[KeyEvent.VK_UP]){
			vy -= velocity;
			dir = UP;
		}else if(km.keys[KeyEvent.VK_S] || km.keys[KeyEvent.VK_DOWN]){
			vy += velocity;
			dir = DOWN;
		}
		
		move(vx, vy);
		
		if(xo + x < 0) xo = -x;
		if(yo + y < 0) yo = -y;
		if(xo + x + Game.TILESIZE > LevelManager.getCurrentLevel().mapWidth * Game.TILESIZE) xo = LevelManager.getCurrentLevel().mapWidth * Game.TILESIZE - x - Game.TILESIZE;
		if(yo + y + Game.TILESIZE > LevelManager.getCurrentLevel().mapHeight * Game.TILESIZE) yo = LevelManager.getCurrentLevel().mapHeight * Game.TILESIZE - y - Game.TILESIZE;
		
		if(!canShoot){
			shootTimer++;
			if(shootTimer >= canShootTime){
				shootTimer = 0;
				canShoot = true;
			}
		}
		
		if(km.keys[KeyEvent.VK_SPACE] && canShoot){
			canShoot = false;
			if(dir == UP)
				shoot(UP);
			else if(dir == LEFT)
				shoot(LEFT);
			else if(dir == RIGHT)
				shoot(RIGHT);
			else
				shoot(DOWN);
		}
		
		if(!canPlaceBomb){
			bombTimer++;
			if(bombTimer >= canPlaceTime){
				bombTimer = 0;
				canPlaceBomb = true;
			}
		}
		
		if(km.keys[KeyEvent.VK_X] && canPlaceBomb){
			if(tnt > 0){
				tnt--;
				canPlaceBomb = false;
				GameState.objects.add(new Bomb(xo + x, yo + y));
			}else{
				
			}
		}
		
		upAnimation.tick();
		downAnimation.tick();
		leftAnimation.tick();
		rightAnimation.tick();
		
		checkWin();
	}
	
	public void checkWin(){
		if(scrap >= winScrap){
			active = false;
			MenuManager.setCurrentMenu(new GameOverMenu(score, true));
		}
	}
	
	public void shoot(int where){
		if(where == UP){
			GameState.objects.add(new Bullet(xo + x, yo + y, 0, -4));
		}else if(where == LEFT){
			GameState.objects.add(new Bullet(xo + x, yo + y, -4, 0));
		}else if(where == RIGHT){
			GameState.objects.add(new Bullet(xo + x, yo + y, 4, 0));
		}else{
			GameState.objects.add(new Bullet(xo + x, yo + y, 0, 4));
		}
		
		Sound.shootClip.play();
	}
	
	public void endGame(){
		active = false;
		MenuManager.setCurrentMenu(new GameOverMenu(score, false));
	}
	
	public void hurt(int amount){
		health -= amount;
		if(health <= 0){
			endGame();
		}
		Sound.hurtClip.play();
	}
	
	public Rectangle getBounds(){
		return new Rectangle(xo + x + 5, yo + y, Game.TILESIZE - 10, Game.TILESIZE);
	}
	
	public boolean collision(int vx, int vy){
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + 6) / Game.TILESIZE, (yo + vy + y) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + 18 + 6) / Game.TILESIZE, (yo + vy + y) / Game.TILESIZE).isSolid()) return true;
		
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + 6) / Game.TILESIZE, (yo + vy + y + Game.TILESIZE - 1) / Game.TILESIZE).isSolid()) return true;
		if(LevelManager.getCurrentLevel().getTile((xo + vx + x + 18 + 6) / Game.TILESIZE, (yo + vy + y + Game.TILESIZE - 1) / Game.TILESIZE).isSolid()) return true;
		
		return false;
	}
	
	public void render(Screen screen) {
		if(dir == UP)
			upAnimation.render(screen, x, y);
		else if(dir == DOWN)
			downAnimation.render(screen, x, y);
		else if(dir == LEFT)
			leftAnimation.render(screen, x, y);
		else
			rightAnimation.render(screen, x, y);
	}

}