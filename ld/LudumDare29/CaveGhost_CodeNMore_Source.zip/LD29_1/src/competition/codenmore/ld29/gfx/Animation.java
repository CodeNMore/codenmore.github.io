package competition.codenmore.ld29.gfx;

public class Animation {

	private Image i1, i2;
	private int timer = 0, speed;
	private boolean switched = false;
	
	public Animation(Image i1, Image i2, int speed){
		this.i1 = i1;
		this.i2 = i2;
		this.speed = speed;
	}
	
	public void tick(){
		timer++;
		if(timer > speed){
			timer = 0;
			switched = !switched;
		}
	}
	
	public void render(Screen screen, int x, int y){
		if(switched)
			screen.render(i1, x, y);
		else
			screen.render(i2, x, y);
	}
	
}
