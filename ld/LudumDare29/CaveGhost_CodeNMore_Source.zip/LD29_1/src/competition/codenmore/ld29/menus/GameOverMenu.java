package competition.codenmore.ld29.menus;

import java.awt.event.KeyEvent;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.controls.KeyManager;
import competition.codenmore.ld29.gfx.Font;
import competition.codenmore.ld29.gfx.Screen;

public class GameOverMenu extends Menu {

	protected int score;
	private boolean won;
	private KeyManager km = Game.getKeyManager();
	
	public GameOverMenu(int score, boolean won){
		this.score = score;
		this.won = won;
	}
	
	public void tick() {
		if(km.keys[KeyEvent.VK_X]){
			MenuManager.setCurrentMenu(new MainMenu());
		}
	}

	public void render(Screen screen) {
		Font.renderFont(screen, "YOU KILLED", 120, 30);
		Font.renderFont(screen, Integer.toString(score) + " GHOSTS", 160, 90);
		
		if(won){
			Font.renderFont(screen, "AND GOT ENOUGH", 50, 180);
			Font.renderFont(screen, "SCRAP TO BUILD", 50, 230);
			Font.renderFont(screen, "A SHUTTLE HOME!", 50, 280);
		}
		else{
			Font.renderFont(screen, "BUT DID NOT GET", 50, 180);
			Font.renderFont(screen, "ENOUGH SCRAP TO", 50, 230);
			Font.renderFont(screen, "GET HOME!", 180, 280);
		}
			
		Font.renderFont(screen, "PRESS X TO", 130, 360);
		Font.renderFont(screen, "TRY  AGAIN!", 130, 410);
	}

}
