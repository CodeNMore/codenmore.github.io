package competition.codenmore.ld29.entities;

import java.util.ArrayList;

import competition.codenmore.ld29.gfx.Screen;

public class EntityManager {

	public static ArrayList<Entity> entities = new ArrayList<Entity>();
	
	public void addEntity(Entity e){
		entities.add(e);
	}
	
	public static void removeEntity(Entity e){
		entities.remove(e);
	}
	
	public void tick(){
		for(int i = 0;i < entities.size();i++){
			if(entities.get(i).active)
				entities.get(i).tick();
			else
				entities.remove(i);
		}
	}
	
	public void render(Screen screen){
		for(Entity e : entities){
			e.render(screen);
		}
	}
	
}