package competition.codenmore.ld29.objects;

import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.menus.GameState;
import competition.codenmore.ld29.objects.Object;
import competition.codenmore.ld29.sfx.Sound;

public class Scrap extends Object {
	
	public Scrap(int xo, int yo){
		this.xo = xo;
		this.yo = yo;
	}

	public void tick() {
		if(active && getBounds().intersects(GameState.getPlayer().getBounds())){
			GameState.getPlayer().scrap++;
			Sound.collectClip.play();
			active = false;
		}
	}

	public void render(Screen screen) {
		screen.render(ImageManager.scrap, xo - GameState.getPlayer().getXOffset(), yo - GameState.getPlayer().getYOffset());
	}

}
