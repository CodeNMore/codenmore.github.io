package competition.codenmore.ld29.gfx;

public class ImageManager {
	
	static SpriteSheet s = new SpriteSheet("/textures/sheet.png", 32);
	
	public static Image playerDown = s.crop(0, 0), playerUp = s.crop(0, 1), 
						playerLeft = s.crop(0, 2), playerRight = s.crop(0, 3),
						playerDown2 = s.crop(0, 4), playerUp2 = s.crop(0, 5), 
						playerLeft2 = s.crop(0, 6), playerRight2 = s.crop(0, 7), 
						backTile = s.crop(1, 0), wallTile = s.crop(2, 0),
						ghost1 = s.crop(1, 1), ghost2 = s.crop(2, 1),
						bullet = s.crop(1, 2), scrap = s.crop(2, 2),
						heart = s.crop(1, 3), tnt1 = s.crop(2, 3),
						tnt2 = s.crop(1, 4), tntMini = s.crop(2, 4);
}