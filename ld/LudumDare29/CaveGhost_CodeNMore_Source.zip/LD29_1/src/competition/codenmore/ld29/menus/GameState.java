package competition.codenmore.ld29.menus;

import java.util.ArrayList;

import competition.codenmore.ld29.entities.EntityManager;
import competition.codenmore.ld29.entities.Player;
import competition.codenmore.ld29.gfx.ExternalImageLoader;
import competition.codenmore.ld29.gfx.Font;
import competition.codenmore.ld29.gfx.Image;
import competition.codenmore.ld29.gfx.ImageManager;
import competition.codenmore.ld29.gfx.Screen;
import competition.codenmore.ld29.levels.Level;
import competition.codenmore.ld29.levels.LevelManager;
import competition.codenmore.ld29.objects.Object;

public class GameState extends Menu{
	
	public static EntityManager entityManager;
	public static ArrayList<Object> objects = new ArrayList<Object>();
	
	private static Player player;
	private Image lighting;
	
	public GameState(){
		ExternalImageLoader l = new ExternalImageLoader();
		lighting = new Image(1, 1);
		lighting.pixels = l.loadExternalImage("/textures/lighting.png");
		lighting.w = l.w;
		lighting.h = l.h;
		
		player = new Player(10);
		entityManager = new EntityManager();
		entityManager.addEntity(player);
		
		LevelManager.setCurrentLevel(new Level(70, 70, 34, 12, 18));//mapWidth, mapHeight, Ghosts, Scrap, Bombs
	}

	public void tick() {
		entityManager.tick();
		
		for(int i = 0;i < objects.size();i++){
			if(objects.get(i).active)
				objects.get(i).tick();
			else
				objects.remove(i);
		}
	}

	public void render(Screen screen) {
		if(LevelManager.getCurrentLevel() != null)
			LevelManager.getCurrentLevel().render(screen);
		entityManager.render(screen);
		
		for(Object o : objects)
			o.render(screen);
		
		screen.render(lighting, 0, 0);
		
		screen.render(ImageManager.tnt1, 12, 10);
		Font.renderFont(screen, Integer.toString(player.tnt) + " X TO PLACE", 50, 10);
		
		screen.render(ImageManager.heart, 12, 430);
		Font.renderFont(screen, Integer.toString(player.health), 50, 430);
		
		Font.renderFont(screen, "SCRAP:  /10", 200, 430);
		Font.renderFont(screen, Integer.toString(player.scrap), 398, 430);
	}
	
	public static Player getPlayer(){
		return player;
	}

}