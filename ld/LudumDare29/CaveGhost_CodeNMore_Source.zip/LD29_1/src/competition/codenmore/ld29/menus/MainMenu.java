package competition.codenmore.ld29.menus;

import java.awt.event.KeyEvent;

import competition.codenmore.ld29.Game;
import competition.codenmore.ld29.controls.KeyManager;
import competition.codenmore.ld29.gfx.ExternalImageLoader;
import competition.codenmore.ld29.gfx.Image;
import competition.codenmore.ld29.gfx.Screen;

public class MainMenu extends Menu{

	private KeyManager km = Game.getKeyManager();
	private Image m1, m2;
	private boolean switched = false;
	private int timer = 0, change = 30;
	
	public MainMenu(){
		ExternalImageLoader l = new ExternalImageLoader();
		m1 = new Image(1, 1);
		m2 = new Image(1, 1);
		
		m1.pixels = l.loadExternalImage("/textures/mainmenu.png");
		m1.w = l.w;
		m1.h = l.h;
		
		m2.pixels = l.loadExternalImage("/textures/mainmenu2.png");
		m2.w = l.w;
		m2.h = l.h;
	}
	
	public void tick() {
		if(km.keys[KeyEvent.VK_SPACE])
			MenuManager.setCurrentMenu(new GameState());
		timer++;
		if(timer > change){
			timer = 0;
			switched = !switched;
		}
	}

	public void render(Screen screen) {
		if(switched)
			screen.render(m2, 0, 0);
		else
			screen.render(m1, 0, 0);
	}

}
