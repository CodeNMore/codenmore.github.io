package competition.codenmore.ld30.util;

public class Timer {

	private boolean isNano, reset = true;
	private long timer, now, lastTime;
	
	public Timer(boolean isNano){
		this.isNano = isNano;
		timer = 0;
		if(isNano)
			lastTime = nano();
		else
			lastTime = mill();
	}
	
	public void update(){
		if(reset){
			if(isNano)
				lastTime = nano();
			else
				lastTime = mill();
			
			reset = false;
		}
		
		if(isNano)
			now = nano();
		else
			now = mill();
		
		timer += now - lastTime;
		lastTime = now;
	}
	
	public long getTimer(){
		return timer;
	}
	
	public int getTimerInt(){
		return (int) timer;
	}
	
	public void reset(){
		timer = 0;
		reset = true;
	}
	
	private long mill(){
		return System.currentTimeMillis();
	}
	
	private long nano(){
		return System.nanoTime();
	}
	
}
