package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.entities.Parts;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.map.Map;
import competition.codenmore.ld30.map.Planet;
import competition.codenmore.ld30.sfx.SoundManager;

public class MapState extends State{

	private static Map map;
	private int screenID = 0;
	private boolean lifted1, lifted2, lifted3, lifted4, liftedb;
	
	public MapState(){
		map = new Map(Game.WIDTH, Game.HEIGHT - 60);
	}
	
	public void tick() {
		if(!liftedb && !Game.getKeyManager().keys[KeyManager.B])
			liftedb = true;
		
		if(screenID == 0){//MAP
			map.tick();
			
			if(Game.getKeyManager().keys[KeyManager.U]){
				screenID = 1;
				SoundManager.select.play();
			}
			
			if(map.getSelected() >= 0 && map.getSelected() < map.getPlanets().length && GameState.getPlayer().getMaxDistance() >= Planet.distance(map.getPlanets()[map.getSelected()], map.getLocation()) && Game.getKeyManager().keys[KeyManager.S]){
				State.setState(Game.campaignState);
				((CampaignState) Game.campaignState).setTravelingDistance(Planet.distance(map.getPlanets()[map.getSelected()], map.getLocation()));
			}
			
			if(liftedb && Game.getKeyManager().keys[KeyManager.B]){
				State.setState(Game.menuState);
				liftedb = false;
			}
				
		}else{//UPGRADE
			if(!lifted1 && !Game.getKeyManager().keys[KeyManager.N1])
				lifted1 = true;
			if(!lifted2 && !Game.getKeyManager().keys[KeyManager.N2])
				lifted2 = true;
			if(!lifted3 && !Game.getKeyManager().keys[KeyManager.N3])
				lifted3 = true;
			if(!lifted4 && !Game.getKeyManager().keys[KeyManager.N4])
				lifted4 = true;
			
			if(lifted1 && Game.getKeyManager().keys[KeyManager.N1]){//distance
				if(GameState.getPlayer().getCurrency() >= Parts.getMaxDistanceCost()){
					GameState.getPlayer().addCurrency(-Parts.getMaxDistanceCost());
					GameState.getPlayer().addMaxDistance(1);
					Parts.addMaxDistanceCost(10);
					lifted1 = false;
					SoundManager.purchase.play();
				}else{
					SoundManager.dud.play();
					lifted1 = false;
				}
			}
			if(lifted2 && Game.getKeyManager().keys[KeyManager.N2]){//health
				if(GameState.getPlayer().getCurrency() >= Parts.getHealthCost()){
					GameState.getPlayer().addCurrency(-Parts.getHealthCost());
					GameState.getPlayer().addAddedHealth(1);
					Parts.addHealthCost(15);
					lifted2 = false;
					SoundManager.purchase.play();
				}else{
					SoundManager.dud.play();
					lifted2 = false;
				}
			}
			if(lifted3 && Game.getKeyManager().keys[KeyManager.N3]){//health
				if(GameState.getPlayer().getCurrency() >= Parts.getPassengerCost()){
					GameState.getPlayer().addCurrency(-Parts.getPassengerCost());
					GameState.getPlayer().addPassengers(1);
					Parts.addPassengerCost(10);
					lifted3 = false;
					SoundManager.purchase.play();
				}else{
					SoundManager.dud.play();
					lifted3 = false;
				}
			}
			if(lifted4 && Game.getKeyManager().keys[KeyManager.N4]){//health
				if(GameState.getPlayer().getCurrency() >= Parts.getOverheatCost()){
					GameState.getPlayer().addCurrency(-Parts.getOverheatCost());
					GameState.getPlayer().addAddedOverheat(2);
					Parts.addOverheatCost(15);
					lifted4 = false;
					SoundManager.purchase.play();
				}else{
					SoundManager.dud.play();
					lifted4 = false;
				}
			}
			
			if(Game.getKeyManager().keys[KeyManager.M]){
				screenID = 0;
				SoundManager.select.play();
			}
			
			if(liftedb && Game.getKeyManager().keys[KeyManager.B]){
				State.setState(Game.menuState);
				liftedb = false;
			}
		}
	}

	public void render(Screen screen) {
		if(screenID == 0){//Map
			map.render(screen, 0, 0);
			
			if(map.getSelected() >= 0 && map.getSelected() < map.getPlanets().length && GameState.getPlayer().getMaxDistance() >= Planet.distance(map.getPlanets()[map.getSelected()], map.getLocation()))
				Font.renderStringSmall(screen, "<S> Start", 10, Game.HEIGHT - 50);
			else if(map.getSelected() >= 0 && map.getSelected() < map.getPlanets().length)
				Font.renderStringSmall(screen, "Destination too far!", 10, Game.HEIGHT - 50);
			else
				Font.renderStringSmall(screen, "Select Destination", 10, Game.HEIGHT - 50);
			
			Font.renderStringSmall(screen, "<U> Upgrades      <B> Menu", 10, Game.HEIGHT - 20);
		}else{//Upgrade
			Font.renderStringLarge(screen, "Your Parts:" + GameState.getPlayer().getCurrency(), 5, 10);
			Font.renderStringSmall(screen, "<1>Max Distance +1 - " + Parts.getMaxDistanceCost() + " Parts", 5, 50);
			Font.renderStringSmall(screen, "<2>Hull Armor +1 - " + Parts.getHealthCost() + " Parts", 5, 90);
			Font.renderStringSmall(screen, "<3>Passengers +1 - " + Parts.getPassengerCost() + " Parts", 5, 130);
			Font.renderStringSmall(screen, "<4>Gun Overheat +2 - " + Parts.getOverheatCost() + " Parts", 5, 170);
			
			Font.renderStringSmall(screen, "More passengers means more", 5, 250);
			Font.renderStringSmall(screen, "parts earned per trip!", 5, 290);
			
			Font.renderStringSmall(screen, "<M> Map           <B> Menu", 10, Game.HEIGHT - 20);
		}
	}

	public void onShow() {
		screenID = 0;
		map.setSelected(-1);
		lifted1 = false;
		lifted2 = false;
		lifted3 = false;
		lifted4 = false;
		liftedb = false;
	}

	public void onHide() {
		
	}

	public static Map getMap() {
		return map;
	}

	public static void setMap(Map map) {
		MapState.map = map;
	}

}
