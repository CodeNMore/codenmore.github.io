package competition.codenmore.ld30.gfx;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

public class Screen extends Image{

	public BufferedImage screenImage;
	
	public Screen(int width, int height) {
		super(width, height);
		screenImage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
		pixels = ((DataBufferByte) screenImage.getRaster().getDataBuffer()).getData();
	}
	
}
