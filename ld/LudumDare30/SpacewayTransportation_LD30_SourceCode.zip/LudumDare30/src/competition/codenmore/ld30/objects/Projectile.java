package competition.codenmore.ld30.objects;

import java.awt.Rectangle;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.gfx.Colors;
import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.states.GameState;

public class Projectile{

	public static final Image texture = new Image(2, 6);
	public static final int UP = -1, DOWN = 1;
	
	private Rectangle bounds;
	private float x, y, speed = 7.5f;
	private int direction;
	private boolean isPlayerProjectile;
	
	public Projectile(int direction, float x, float y, boolean isPlayerProjectile){
		texture.clear(Colors.WHITE);
		this.direction = direction;
		this.x = x;
		this.y = y;
		this.isPlayerProjectile = isPlayerProjectile;
		bounds = new Rectangle((int) x, (int) y, texture.width, texture.height);
	}
	
	public boolean tick(){
		if(direction == UP){
			y -= speed;
		}else{
			y += speed;
		}
		
		if(!isPlayerProjectile && getBounds().intersects(GameState.getPlayer().getBounds())){
			GameState.getPlayer().hit(-1);
			return true;
		}
		
		if(y + texture.height < 0 || y > Game.HEIGHT)
			return true;
		
		return false;
	}
	
	public void render(Screen screen){
		screen.render(texture, (int) x, (int) y);
	}
	
	public Rectangle getBounds(){
		bounds.x = (int) x;
		bounds.y = (int) y;
		return bounds;
	}
	
	//GETTERS/SETTERS
	
	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public boolean isPlayerProjectile() {
		return isPlayerProjectile;
	}

	public void setPlayerProjectile(boolean isPlayerProjectile) {
		this.isPlayerProjectile = isPlayerProjectile;
	}
	
}
