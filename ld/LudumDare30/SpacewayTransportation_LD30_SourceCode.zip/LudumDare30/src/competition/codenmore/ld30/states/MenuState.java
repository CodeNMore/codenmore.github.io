package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class MenuState extends State {

	private static Background bg;
	
	public MenuState(){
		bg = new Background(TextureManager.background, TextureManager.background, 0.25f);
	}
	
	public void tick() {
		input();
		bg.tick();
	}

	public void render(Screen screen) {
		bg.render(screen);
		Font.renderStringLarge(screen, "Spaceway", 80, 40);
		Font.renderStringLarge(screen, "Transportation", 16, 80);
		
		Font.renderStringLarge(screen, "<R> Campaign", 16, 170);
		Font.renderStringLarge(screen, "<E> Endless", 16, 230);
		Font.renderStringLarge(screen, "<I> Info", 16, 290);
		
		Font.renderStringLarge(screen, "By CodeNMore", 40, 380);
		Font.renderStringLarge(screen, "For Ludum Dare", 20, 420);
	}
	
	private void input(){
		if(Game.getKeyManager().keys[KeyManager.R])
			State.setState(Game.storyState);
		if(Game.getKeyManager().keys[KeyManager.E])
			State.setState(Game.endlessState);
		if(Game.getKeyManager().keys[KeyManager.I])
			State.setState(Game.infoState);
	}

	public void onShow() {
		
	}

	public void onHide() {
		
	}

}
