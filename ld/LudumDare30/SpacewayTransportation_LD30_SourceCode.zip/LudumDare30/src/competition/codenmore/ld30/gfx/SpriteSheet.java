package competition.codenmore.ld30.gfx;

public class SpriteSheet {

	private Image image;
	
	public SpriteSheet(Image image){
		this.image = image;
	}
	
	public Image crop(int xp, int yp, int w, int h){
		Image ret = new Image(w, h);
		
		for(int y = 0;y < h;y++)
			for(int x = 0;x < w;x++)
				ret.pixels[x + y * w] = image.pixels[(x + xp) + (y + yp) * image.width];
		
		return ret;
	}
	
}
