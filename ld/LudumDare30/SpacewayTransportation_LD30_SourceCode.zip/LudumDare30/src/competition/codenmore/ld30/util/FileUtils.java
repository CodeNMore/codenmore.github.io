package competition.codenmore.ld30.util;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

import competition.codenmore.ld30.gfx.Image;

public class FileUtils {

	private volatile static FileUtils instance;
	private static Color c;
	private static byte r;
	
	public static byte[] bufferedImageToByteArray(BufferedImage image){
		int width = image.getWidth();
		int height = image.getHeight();
		byte[] ret = new byte[width * height];
		
		for(int y = 0;y < height;y++){
			for(int x = 0;x < width;x++){
				c = new Color(image.getRGB(x, y));
				r = (byte) c.getRed();
				ret[x + y * width] = r;
			}
		}
		
		return ret;
	}
	
	public static String loadAsString(String path){
		String ret = "";
		
		try{
			BufferedReader br = new BufferedReader(new FileReader(path));
			
			String line = "";
			while((line = br.readLine()) != null)
				ret += line + "\n";
			
			br.close();
		}catch(IOException e){
			e.printStackTrace();
			System.exit(1);
		}
		
		return ret;
	}
	
	public static Image loadAsImage(String path){
		BufferedImage image = instance().loadAsBufferedImage(path);
		Image ret = new Image(image.getWidth(), image.getHeight());
		
		ret.pixels = bufferedImageToByteArray(image);
		
		return ret;
	}
	
	public BufferedImage loadAsBufferedImage(String path){
		try {
			return ImageIO.read(getClass().getResource(path));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		return null;
	}
	
	
	public static FileUtils instance(){
		if(instance == null)
			instance = new FileUtils();
		return instance;
	}
	
}
