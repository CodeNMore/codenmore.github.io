package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.sfx.SoundManager;

public class StoryState extends State {

	private Background bg;
	private int textLayer = 0, amountLayers = 9;
	private boolean lifted = false, dontdostate = false;

	public StoryState() {
		bg = new Background(TextureManager.background,
				TextureManager.background, 0.25f);
	}

	public void tick() {
		bg.tick();

		if (!lifted && !Game.getKeyManager().keys[KeyManager.R])
			lifted = true;

		if (lifted && Game.getKeyManager().keys[KeyManager.R]) {
			lifted = false;
			textLayer++;
			if (textLayer > amountLayers){
				dontdostate = true;
				State.setState(Game.mapState);
			}
			
			SoundManager.select.play();
		}
	}

	public void render(Screen screen) {
		if (dontdostate)
			State.setState(Game.mapState);
		else {
			bg.render(screen);
			if (textLayer == 0) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Hello.", 120, 30);
				Font.renderStringLarge(screen, "My name is", 120, 70);
				Font.renderStringLarge(screen, "Sid Dirkman.", 104, 110);
				Font.renderStringLarge(screen, "I am your", 120, 150);
				Font.renderStringLarge(screen, "Boss here at", 20, 190);
				Font.renderStringLarge(screen, "Spaceway", 20, 230);
				Font.renderStringLarge(screen, "Transportation", 20, 270);
				Font.renderStringLarge(screen, "Incorporated.", 20, 310);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 1) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Let us", 120, 30);
				Font.renderStringLarge(screen, "begin the", 120, 70);
				Font.renderStringLarge(screen, "orientation", 108, 110);
				Font.renderStringLarge(screen, "You", 120, 150);
				Font.renderStringLarge(screen, "are a space", 20, 190);
				Font.renderStringLarge(screen, "pilot, right?", 20, 230);
				Font.renderStringLarge(screen, "Your job is to", 20, 270);
				Font.renderStringLarge(screen, "shuttle aliens", 20, 310);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 2) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "from", 120, 30);
				Font.renderStringLarge(screen, "planet-to-", 120, 70);
				Font.renderStringLarge(screen, "planet.", 120, 110);
				Font.renderStringLarge(screen, "You are to", 20, 190);
				Font.renderStringLarge(screen, "ensure the", 20, 230);
				Font.renderStringLarge(screen, "safety of your", 20, 270);
				Font.renderStringLarge(screen, "passengers.", 20, 310);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 3) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Think of", 120, 30);
				Font.renderStringLarge(screen, "us as a", 120, 70);
				Font.renderStringLarge(screen, "taxi", 120, 110);
				Font.renderStringLarge(screen, "company,as", 120, 150);
				Font.renderStringLarge(screen, "you would call", 20, 190);
				Font.renderStringLarge(screen, "it back on", 20, 230);
				Font.renderStringLarge(screen, "Earth-just you", 10, 270);
				Font.renderStringLarge(screen, "are driving a", 10, 310);
				Font.renderStringLarge(screen, "space shuttle.", 10, 350);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 4) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Controls-", 120, 30);
				Font.renderStringLarge(screen, "you press", 120, 70);
				Font.renderStringLarge(screen, "<SPACE> to", 120, 110);
				Font.renderStringLarge(screen, "fire your", 120, 150);
				Font.renderStringLarge(screen, "gun.", 20, 190);
				Font.renderStringLarge(screen, "Use", 20, 230);
				Font.renderStringLarge(screen, "WASD or the", 20, 270);
				Font.renderStringLarge(screen, "arrow keys to", 20, 310);
				Font.renderStringLarge(screen, "move around.", 20, 350);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 5) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Good", 120, 30);
				Font.renderStringLarge(screen, "luck,", 120, 70);
				Font.renderStringLarge(screen, "it was", 120, 110);
				Font.renderStringLarge(screen, "nice", 120, 150);
				Font.renderStringLarge(screen, "knowing you-", 20, 190);
				Font.renderStringLarge(screen, "I mean meeting", 20, 230);
				Font.renderStringLarge(screen, "you.Do good or", 20, 270);
				Font.renderStringLarge(screen, "you are fired!", 20, 310);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 6) {
				screen.render(TextureManager.guy2, 0, 26);
				Font.renderStringLarge(screen, "Bro, be", 120, 30);
				Font.renderStringLarge(screen, "careful", 120, 70);
				Font.renderStringLarge(screen, "out there.", 120, 110);
				Font.renderStringLarge(screen, "The different", 20, 190);
				Font.renderStringLarge(screen, "planets do not", 20, 230);
				Font.renderStringLarge(screen, "like people to", 20, 270);
				Font.renderStringLarge(screen, "fly near them,", 20, 310);
				Font.renderStringLarge(screen, "which is", 20, 350);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 7) {
				screen.render(TextureManager.guy2, 0, 26);
				Font.renderStringLarge(screen, "exactly", 120, 30);
				Font.renderStringLarge(screen, "what we do", 120, 70);
				Font.renderStringLarge(screen, "at this job.", 100, 110);
				Font.renderStringLarge(screen, "Use your gun,", 20, 190);
				Font.renderStringLarge(screen, "and avoid all", 20, 230);
				Font.renderStringLarge(screen, "things that", 20, 270);
				Font.renderStringLarge(screen, "come at you.", 20, 310);
				Font.renderStringLarge(screen, "Good luck.", 20, 350);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else if (textLayer == 8) {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "Oh, 1 more", 120, 30);
				Font.renderStringLarge(screen, "thing.Use", 120, 70);
				Font.renderStringLarge(screen, "the map", 120, 110);
				Font.renderStringLarge(screen, "screen to", 120, 150);
				Font.renderStringLarge(screen, "choose where", 20, 190);
				Font.renderStringLarge(screen, "you want to", 20, 230);
				Font.renderStringLarge(screen, "travel to.", 20, 270);
				Font.renderStringLarge(screen, "the longer the", 20, 310);
				Font.renderStringLarge(screen, "distance, the", 20, 350);
				Font.renderStringLarge(screen, "<R> Continue ->", 10, 410);
			} else {
				screen.render(TextureManager.guy1, 0, 26);
				Font.renderStringLarge(screen, "longer the", 120, 30);
				Font.renderStringLarge(screen, "time it", 120, 70);
				Font.renderStringLarge(screen, "takes to", 120, 110);
				Font.renderStringLarge(screen, "travel", 120, 150);
				Font.renderStringLarge(screen, "there! Also", 20, 190);
				Font.renderStringLarge(screen, "upgrade your", 20, 230);
				Font.renderStringLarge(screen, "ship so you", 20, 270);
				Font.renderStringLarge(screen, "can travel", 20, 310);
				Font.renderStringLarge(screen, "safer! Bye!", 20, 350);
				Font.renderStringLarge(screen, "<R> Map ->", 10, 410);
				
			}
		}
	}

	public void onShow() {
		textLayer = 0;
		lifted = false;
	}

	public void onHide() {

	}

}
