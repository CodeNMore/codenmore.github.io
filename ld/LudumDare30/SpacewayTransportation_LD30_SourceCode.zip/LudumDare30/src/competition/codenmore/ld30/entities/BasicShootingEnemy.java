package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.objects.Projectile;
import competition.codenmore.ld30.sfx.SoundManager;
import competition.codenmore.ld30.states.GameState;
import competition.codenmore.ld30.util.Timer;

public class BasicShootingEnemy extends Enemy{

	private Timer shootTimer;
	private int shootTimerThresh = 550;
	private static int START_HEALTH;
	private boolean active = true;
	
	public BasicShootingEnemy(float x, float y, int startHealth) {
		super(TextureManager.enemy1, x, y, startHealth, 2.5f);
		START_HEALTH = startHealth;
		shootTimer = new Timer(false);
	}

	public void tick() {
		followPlayerX();
		if(y < getHeight() / 2)
			ys = speed;
		else
			ys = 0;
		move();
		
		shootTimer.update();
		if(shootTimer.getTimer() >= shootTimerThresh){
			shootTimer.reset();
			GameState.getLevel().getProjectiles().add(new Projectile(Projectile.DOWN, x + texture.width / 2, y + texture.height + 2, false));
			SoundManager.shot.play();
		}
		
		if(active && GameState.getPlayer().getBounds().intersects(getBounds())){
			GameState.getPlayer().hit(-1);
			active = false;
		}
	}

	public void render(Screen screen) {
		screen.render(texture, (int) x, (int) y);
	}
	
	public void reset() {
		health = START_HEALTH;
		active = true;
	}

}
