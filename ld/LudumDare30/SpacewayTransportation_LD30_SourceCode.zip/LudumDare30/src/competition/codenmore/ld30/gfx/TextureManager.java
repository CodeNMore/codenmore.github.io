package competition.codenmore.ld30.gfx;

import competition.codenmore.ld30.util.FileUtils;

public class TextureManager {

	private static final int SIZE = 64;
	
	public static Image player, enemy1;
	public static Image asteroid1, asteroid2;
	public static SpriteSheet fontSheet, fontSheetSmall;
	public static Image background;
	public static Image guy1, guy2;
	public static Image planet1, planet2, planet3, planet4;
	public static Image selected, selectedHere;
	public static Image[] ui;
	
	public static void init(SpriteSheet sheet){
		//Players
		player = sheet.crop(0, 0, 36, 36);
		enemy1 = sheet.crop(0, SIZE, 36, 36);
			
		//People
		guy1 = sheet.crop(SIZE * 3, 0, SIZE * 2, SIZE * 2);
		guy2 = sheet.crop(SIZE * 5, 0, SIZE * 2, SIZE * 2);
		
		//Planets
		planet1 = sheet.crop(0, SIZE * 2, SIZE, SIZE);
		planet2 = sheet.crop(0, SIZE * 3, SIZE, SIZE);
		planet3 = sheet.crop(SIZE, SIZE * 3, SIZE, SIZE);
		planet4 = sheet.crop(0, SIZE * 4, SIZE, SIZE);
		
		//GameObjects
		asteroid1 = sheet.crop(SIZE, SIZE * 2, SIZE, SIZE);
		asteroid2 = sheet.crop(SIZE * 2, SIZE * 2, SIZE * 2, SIZE * 2);
		
		//Other
		fontSheet = new SpriteSheet(FileUtils.loadAsImage("/font_large.png"));
		fontSheetSmall = new SpriteSheet(FileUtils.loadAsImage("/font_small.png"));
		background = FileUtils.loadAsImage("/bg.png");
		selectedHere = sheet.crop(SIZE * 4, SIZE * 2, SIZE, SIZE);
		selected = sheet.crop(SIZE * 5, SIZE * 2, SIZE, SIZE);
		
		ui = new Image[3];
			ui[0] = sheet.crop(SIZE * 4, SIZE * 3, 16, 16);
			ui[1] = sheet.crop(SIZE * 5, SIZE * 3, 16, 16);
			ui[2] = sheet.crop(SIZE * 6, SIZE * 3, 16, 16);
	}
	
}
