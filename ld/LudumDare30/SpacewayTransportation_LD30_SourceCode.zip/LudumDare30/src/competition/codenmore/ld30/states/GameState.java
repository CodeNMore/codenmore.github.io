package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.entities.Player;
import competition.codenmore.ld30.entities.UI;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.level.Level;

public abstract class GameState extends State{

	protected static Background bg;
	protected static Player player;
	protected static Level level;
	protected static UI ui;
	
	public GameState(){
		bg = new Background(TextureManager.background, TextureManager.background, 2.5f);
		player = new Player(Game.WIDTH / 2 - TextureManager.player.width / 2, Game.HEIGHT - TextureManager.player.height);
		
		level = new Level();
		ui = new UI(player);
	}

	public void tick() {
		bg.tick();
		level.tick();
		player.tick();
		ui.tick();
	}

	public void render(Screen screen) {
		bg.render(screen);
		level.render(screen);
		player.render(screen);
		ui.render(screen);
	}
	
	protected abstract void levelSet();
	
	public void onShow() {
		levelSet();
		player.setX(Game.WIDTH / 2 - TextureManager.player.width / 2);
		player.setY(Game.HEIGHT - TextureManager.player.height);
	}

	public void onHide() {
		level.stop();
	}
	
	public static Player getPlayer(){
		return player;
	}
	
	public static Level getLevel(){
		return level;
	}
	
}
