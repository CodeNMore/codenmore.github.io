package competition.codenmore.ld30.gfx;

public class Colors {

	public static final byte
		BLACK = (byte) 0x00,
		WHITE = (byte) 0xFF,
		ALPHA = (byte) 0xE0,
		LIGHT = (byte) 0x81;
	
}
