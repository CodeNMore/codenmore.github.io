package competition.codenmore.ld30.map;

import java.awt.Rectangle;

import competition.codenmore.ld30.gfx.Image;

public class Planet{

	private Rectangle bounds;
	private Image texture;
	private int x, y, width, height;
	private int mapPos;
	private String name;
	
	public Planet(Image texture, int x, int y, int width, int height, String name, int mapPos) {
		bounds = new Rectangle(x, y, width, height);
		this.name = name;
		this.mapPos = mapPos;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.texture = texture;
	}
	
	public void render(Image screen){
		screen.render(texture, x, y);
	}
	
	public static int distance(Planet planet, int pos){
		return Math.abs(planet.getMapPos() - pos);
	}
	
	public static int distanceToTime(int distance){
		return 25000 * distance;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
		bounds.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
		bounds.height = height;
	}

	public int getMapPos() {
		return mapPos;
	}

	public void setMapPos(int mapPos) {
		this.mapPos = mapPos;
	}

	public Rectangle getBounds(){
		bounds.x = x;
		bounds.y = y;
		return bounds;
	}

	public Image getTexture() {
		return texture;
	}

	public void setTexture(Image texture) {
		this.texture = texture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
