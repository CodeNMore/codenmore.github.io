package competition.codenmore.ld30.gfx;

public class Image {

	private boolean skip = false;
	public int width, height;
	public byte[] pixels;
	
	public Image(int width, int height){
		this.width = width;
		this.height = height;
		pixels = new byte[width * height];
	}
	
	public void render(Image image, int xp, int yp){
		for(int y = 0;y < image.height;y++){
			for(int x = 0;x < image.width;x++){
				if(x + xp < 0 || y + yp < 0 || x + xp >= width || y + yp >= height)
					skip = true;
				
				if(!skip && image.pixels[x + y * image.width] != Colors.ALPHA)
					pixels[(x + xp) + (y + yp) * width] = image.pixels[x + y * image.width];
				else
					skip = false;
			}
		}
	}
	
	public void clear(byte shade){
		for(int i = 0;i < pixels.length;i++)
			pixels[i] = shade;
	}
	
}
