package competition.codenmore.ld30.states;

import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.level.Level;
import competition.codenmore.ld30.util.Timer;

public class EndlessState extends GameState {

	private Timer timer, scoreTimer;
	private int nextSwitch;
	
	private int delayTime = 2000;
	private static final int duration = 0;
	private static final int STARTPOINTER = 4;
	private int setPointer, campaignOverheatSave;
	private static int score;
	private boolean atEnd;
	
	private int sets[] = {//min, max, enemies, howlong
			750, 1100, 6, 15000,
			600, 800, 6, 15000,
			500, 700, 8, 15000,
			400, 650, 8, 15000,
			300, 550, 11, 30000,
			300, 400, 12, 30000,
			200, 300, 100, 60000,
			100, 200, 10000, 0
	};
	
	public EndlessState(){
		super();
		timer = new Timer(false);
		scoreTimer = new Timer(false);
		atEnd = false;
	}
	
	public void tick(){
		super.tick();
		timer.update();
		scoreTimer.update();
		if(!atEnd && timer.getTimer() >= nextSwitch){
			level.start(sets[setPointer++], sets[setPointer++], delayTime, duration, sets[setPointer++], false);
			nextSwitch = sets[setPointer++];
			
			if(setPointer >= sets.length)
				atEnd = true;
			
			timer.reset();
			
			GameState.getPlayer().addAddedOverheat(3);
		}
		score = scoreTimer.getTimerInt();
	}
	
	public void render(Screen screen){
		super.render(screen);
		Font.renderStringLarge(screen, "Score: " + score, 5, 5);
	}
	
	protected void levelSet(){
		setPointer = STARTPOINTER;
		atEnd = false;
		
		level = new Level();
		level.setMinSpeed(4);
		level.setMaxSpeed(7);
		level.setEnemyGenRand(76);
		level.setEnemyGenModulus(4);
		level.start(sets[0], sets[1], delayTime, duration, sets[2], false);
		nextSwitch = sets[3];
		
		timer.reset();
		scoreTimer.reset();
	}
	
	public void onShow(){
		super.onShow();
		player.setOnEndless(true);
		score = 0;
		campaignOverheatSave = GameState.getPlayer().getAddedOverheat();
		GameState.getPlayer().setAddedOverheat(0);
	}
	
	public void onHide(){
		super.onHide();
		GameState.getPlayer().setAddedOverheat(campaignOverheatSave);
	}
	
	public static int getScore(){
		return score;
	}

}
