package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class DeadStateCampaign extends State {

	private static Background bg;
	
	public DeadStateCampaign(){
		bg = new Background(TextureManager.background, TextureManager.background, 0.25f);
	}
	
	public void tick() {
		bg.tick();
		if(Game.getKeyManager().keys[KeyManager.R])
			State.setState(Game.mapState);
		if(Game.getKeyManager().keys[KeyManager.B])
			State.setState(Game.menuState);
	}

	public void render(Screen screen) {
		bg.render(screen);
		Font.renderStringLarge(screen, "You crashed and", 0, 40);
		Font.renderStringLarge(screen, "killed all of", 20, 80);
		Font.renderStringLarge(screen, "your passengers!", 0, 120);
		
		Font.renderStringLarge(screen, "<R> for map!", 10, 360);
		Font.renderStringLarge(screen, "<B> for menu!", 30, 400);
	}
	
	public void onShow() {
		
	}

	public void onHide() {
		
	}

}
