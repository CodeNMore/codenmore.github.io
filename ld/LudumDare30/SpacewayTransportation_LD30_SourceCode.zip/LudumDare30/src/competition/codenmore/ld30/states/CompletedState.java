package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class CompletedState extends State{

	private static Background bg;
	private int partsEarned;
	private String departedName, arrivalName;

	public CompletedState(){
		bg = new Background(TextureManager.background, TextureManager.background, 0.25f);
	}
	
	public void tick() {
		bg.tick();
		
		if(Game.getKeyManager().keys[KeyManager.R])
			State.setState(Game.mapState);
	}

	public void render(Screen screen) {
		bg.render(screen);
		Font.renderStringLarge(screen, "You", 140, 10);
		Font.renderStringLarge(screen, "successfuly", 60, 50);
		Font.renderStringLarge(screen, "transported", 60, 90);
		Font.renderStringLarge(screen, GameState.getPlayer().getPassengers() + " passengers", 40, 130);
		Font.renderStringLarge(screen, "from " + departedName, 30, 170);
		Font.renderStringLarge(screen, "to " + arrivalName, 30, 210);
		Font.renderStringLarge(screen, "and earned " + partsEarned, 30, 250);
		Font.renderStringLarge(screen, "parts!", 120, 290);
		Font.renderStringSmall(screen, "Total Parts:" + GameState.getPlayer().getCurrency(), 50, 350);
		
		Font.renderStringLarge(screen, "<R> Map", 10, 420);
	}

	public void onShow() {
		GameState.getPlayer().reset();
	}

	public void onHide() {
		
	}
	
	public int getPartsEarned() {
		return partsEarned;
	}

	public void setPartsEarned(int partsEarned) {
		this.partsEarned = partsEarned;
	}

	public String getDepartedName() {
		return departedName;
	}

	public void setDepartedName(String departedName) {
		this.departedName = departedName;
	}

	public String getArrivalName() {
		return arrivalName;
	}

	public void setArrivalName(String arrivalName) {
		this.arrivalName = arrivalName;
	}

}
