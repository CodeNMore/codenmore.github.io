package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.states.GameState;

public abstract class Enemy extends Entity{
	
	protected float speed;
	
	public Enemy(Image texture, float x, float y, int startHealth, float speed){
		super(texture, x, y, texture.width, texture.height, startHealth);
		this.speed = speed;
	}
	
	protected void followPlayerX(){
		xs = 0;
		
		if(GameState.getPlayer().getX() < x)
			xs -= speed;
		else if(GameState.getPlayer().getX() > x)
			xs += speed;
	}
	
	public abstract void reset();
	
}
