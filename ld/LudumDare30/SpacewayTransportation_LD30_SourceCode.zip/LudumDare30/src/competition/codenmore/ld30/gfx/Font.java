package competition.codenmore.ld30.gfx;

public class Font {

	private static final SpriteSheet fontLarge = TextureManager.fontSheet;
	private static final SpriteSheet fontSmall = TextureManager.fontSheetSmall;
	private static final int SIZEL = 20, SIZES = 10;
	
	private static final String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!:?<>()+-/ ";
	
	public static void renderStringLarge(Image screen, String text, int x, int y){
		text = text.toUpperCase();
		int c;
		
		for(int i = 0;i < text.length();i++){
			c = letters.indexOf(text.charAt(i));
			if(c < 0)
				continue;
			
			screen.render(fontLarge.crop(c * SIZEL, 0, SIZEL, SIZEL), x, y);
			x += SIZEL + 2;
		}
	}
	
	public static void renderStringSmall(Image screen, String text, int x, int y){
		text = text.toUpperCase();
		int c;
		
		for(int i = 0;i < text.length();i++){
			c = letters.indexOf(text.charAt(i));
			if(c < 0)
				continue;
			
			screen.render(fontSmall.crop(c * SIZES, 0, SIZES, SIZES), x, y);
			x += SIZES + 2;
		}
	}
	
}
