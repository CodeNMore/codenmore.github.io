package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class DeadStateEndless extends State {
	
	private static Background bg;
	
	public DeadStateEndless(){
		bg = new Background(TextureManager.background, TextureManager.background, 0.25f);
	}

	public void tick() {
		bg.tick();
		if(Game.getKeyManager().keys[KeyManager.R])
			State.setState(Game.endlessState);
		if(Game.getKeyManager().keys[KeyManager.B])
			State.setState(Game.menuState);
	}

	public void render(Screen screen) {
		bg.render(screen);
		Font.renderStringLarge(screen, "You crashed and", 0, 10);
		Font.renderStringLarge(screen, "killed all of", 20, 50);
		Font.renderStringLarge(screen, "your passengers!", 0, 90);
		Font.renderStringLarge(screen, "Score: " + EndlessState.getScore(), 0, 140);
		Font.renderStringLarge(screen, "Bonus: " + GameState.getPlayer().getPreviousKills() * 100, 0, 180);
		Font.renderStringLarge(screen, "Total: " + ((GameState.getPlayer().getPreviousKills() * 100) + EndlessState.getScore()), 0, 220);
		Font.renderStringLarge(screen, "tweet your score", 0, 280);
		Font.renderStringLarge(screen, "at codenmore", 40, 320);
		
		Font.renderStringLarge(screen, "<R> to restart!", 10, 380);
		Font.renderStringLarge(screen, "<B> for menu!", 30, 420);
	}

	public void onShow() {
		
	}

	public void onHide() {
		
	}

}
