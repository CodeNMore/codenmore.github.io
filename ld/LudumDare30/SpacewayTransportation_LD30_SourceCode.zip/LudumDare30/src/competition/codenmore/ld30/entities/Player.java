package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.objects.Projectile;
import competition.codenmore.ld30.sfx.SoundManager;
import competition.codenmore.ld30.states.GameState;
import competition.codenmore.ld30.states.State;
import competition.codenmore.ld30.util.Timer;

public class Player extends Entity{
	
	private boolean lifted = true, onEndless = false;
	private int fireThreshhold = 500;
	private int kills = 0, previousKills = 0;
	private int maxDistance = 1, currency = 3, passengers = 2;

	public static int startHealth = 3;
	private int overheat = 16, heat = 0;
	private int addedOverheat = 0;
	private int addedHealth = 0;

	private float speed = 4f;
	
	private Timer shootTimer;
	private int heatLowerThresh = 300;

	public Player(float x, float y) {
		super(TextureManager.player, x, y, TextureManager.player.width, TextureManager.player.height, startHealth);
		shootTimer = new Timer(false);
	}
	
	public void tick() {
		shootTimer.update();
		input();
		move();
	}
	
	public void render(Screen screen) {
		screen.render(texture, (int) x, (int) y);
	}
	
	public void move(){
		x += xs;
		y += ys;
		
		if(x < 0)
			x = 0;
		else if(x > Game.WIDTH - width)
			x = Game.WIDTH - width;
		
		if(y < 0)
			y = 0;
		else if(y > Game.HEIGHT - height)
			y = Game.HEIGHT - height;
	}
	
	private void input(){
		xs = 0;
		ys = 0;
		
		if(Game.getKeyManager().keys[KeyManager.A] || Game.getKeyManager().keys[KeyManager.LEFT])
			xs -= speed;
		
		if(Game.getKeyManager().keys[KeyManager.D] || Game.getKeyManager().keys[KeyManager.RIGHT])
			xs += speed;
		
		if(Game.getKeyManager().keys[KeyManager.W] || Game.getKeyManager().keys[KeyManager.UP])
			ys -= speed;
		
		if(Game.getKeyManager().keys[KeyManager.S] || Game.getKeyManager().keys[KeyManager.DOWN])
			ys += speed;

		if(!Game.getKeyManager().keys[KeyManager.SPACE])
			lifted = true;
		
		if(shootTimer.getTimer() >= heatLowerThresh){
			heat--;
			if(heat < 0)
				heat = 0;
			shootTimer.reset();
		}
		
		if(lifted && Game.getKeyManager().keys[KeyManager.SPACE])//BULLET
			shoot();
	}
	
	private void shoot(){
		heat++;
		if(heat > overheat + addedOverheat){
			heat = overheat + addedOverheat;
			SoundManager.dud.play();
		}else{
			GameState.getLevel().getProjectiles().add(new Projectile(Projectile.UP, x + texture.width / 2, y - 2, true));
			SoundManager.shot.play();
		}
			
		shootTimer.reset();
		lifted = false;
	}
	
	public void hit(int amount){
		SoundManager.hit.play();
		
		health += amount;
		if(onEndless){
			if(health <= 0)
				die();
		}else{
			if(health + addedHealth <= 0)
				die();
		}
	}
	
	public void die(){
		//Automatically stops level
		SoundManager.boom.play();
		reset();
		if(onEndless)
			State.setState(Game.deadStateEndless);
		else
			State.setState(Game.deadStateCampaign);
	}
	
	public void reset(){
		health = startHealth;
		previousKills = kills;
		kills = 0;
		heat = 0;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

	public int getFireThreshhold() {
		return fireThreshhold;
	}

	public void setFireThreshhold(int fireThreshhold) {
		this.fireThreshhold = fireThreshhold;
	}

	public boolean isOnEndless() {
		return onEndless;
	}

	public void setOnEndless(boolean onEndless) {
		this.onEndless = onEndless;
	}
	
	public void addKill(int num){
		kills += num;
	}
	
	public int getKills(){
		return kills;
	}

	public int getPreviousKills() {
		return previousKills;
	}

	public int getMaxDistance() {
		return maxDistance;
	}

	public int getCurrency() {
		return currency;
	}

	public void setCurrency(int currency) {
		this.currency = currency;
	}
	
	public void addCurrency(int amt){
		currency += amt;
	}

	public void setMaxDistance(int maxDistance) {
		this.maxDistance = maxDistance;
	}
	
	public void addMaxDistance(int amt) {
		maxDistance += amt;
	}
	
	public int getAddedHealth() {
		return addedHealth;
	}

	public void setAddedHealth(int addedHealth) {
		this.addedHealth = addedHealth;
	}
	
	public void addAddedHealth(int amt){
		addedHealth += amt;
	}

	public int getPassengers() {
		return passengers;
	}

	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	
	public void addPassengers(int amt){
		passengers += amt;
	}

	public int getOverheat() {
		return overheat;
	}

	public void setOverheat(int overheat) {
		this.overheat = overheat;
	}

	public int getHeat() {
		return heat;
	}

	public void setHeat(int heat) {
		this.heat = heat;
	}

	public int getAddedOverheat() {
		return addedOverheat;
	}

	public void setAddedOverheat(int addedOverheat) {
		this.addedOverheat = addedOverheat;
	}
	
	public void addAddedOverheat(int amt){
		addedOverheat += amt;
	}
	
}
