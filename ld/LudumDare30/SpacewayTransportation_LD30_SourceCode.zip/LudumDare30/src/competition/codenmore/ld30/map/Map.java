package competition.codenmore.ld30.map;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.gfx.Colors;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.sfx.SoundManager;
import competition.codenmore.ld30.states.GameState;

public class Map {

	private Image mapImage;
	private Planet[] planets;
	private int location = 0;
	private boolean mlifted = false;

	private int selected = -1;
	
	public Map(int width, int height){
		planets = new Planet[4];
			planets[0] = new Planet(TextureManager.planet1, 10, 10, TextureManager.planet1.width, TextureManager.planet1.height, "Dwork", 0);
			planets[1] = new Planet(TextureManager.planet2, 100, 100, TextureManager.planet2.width, TextureManager.planet2.height, "Zentaris", 1);
			planets[2] = new Planet(TextureManager.planet3, 200, 200, TextureManager.planet3.width, TextureManager.planet3.height, "Galgus", 3);
			planets[3] = new Planet(TextureManager.planet4, 50, height - 100, TextureManager.planet4.width, TextureManager.planet4.height, "Zanador", 6);
		
		mapImage = new Image(width, height);
	}
	
	public void tick(){
		if(!mlifted && !Game.getMouseManager().pressed)
			mlifted = true;
			
		if(mlifted && Game.getMouseManager().pressed){
			for(int i = 0;i < planets.length;i++){
				if(i != location && planets[i].getBounds().contains(Game.getMouseManager().MX, Game.getMouseManager().MY)){
					selected = i;
					SoundManager.select.play();
				}
			}
			mlifted = false;
		}
	}
	
	public void render(Screen screen, int x, int y){
		mapImage.clear(Colors.LIGHT);
		
		for(int i = 0;i < planets.length;i++){
			planets[i].render(mapImage);
			if(i == selected)
				mapImage.render(TextureManager.selected, planets[i].getX(), planets[i].getY());
			else if(i == location)
				mapImage.render(TextureManager.selectedHere, planets[i].getX(), planets[i].getY());
		}
		
		Font.renderStringSmall(mapImage, "Location:" + planets[location].getName(), 80, 4);
		if(selected >= 0 && selected < planets.length){
			Font.renderStringSmall(mapImage, "Destination:" + planets[selected].getName(), 80, 24);
			Font.renderStringSmall(mapImage, "Distance:" + Planet.distance(planets[location], planets[selected].getMapPos()) + " LY", 80, 44);
		}else{
			Font.renderStringSmall(mapImage, "Destination:Click One!", 80, 24);
			Font.renderStringSmall(mapImage, "Distance:Select a Dest.", 80, 44);
		}
		Font.renderStringSmall(mapImage, "Max Distance:" + GameState.getPlayer().getMaxDistance() + " LY", 80, 64);
		
		screen.render(mapImage, x, y);
	}
	
	public Planet[] getPlanets() {
		return planets;
	}

	public void setPlanets(Planet[] planets) {
		this.planets = planets;
	}

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public int getSelected() {
		return selected;
	}

	public void setSelected(int selected) {
		this.selected = selected;
	}
	
}
