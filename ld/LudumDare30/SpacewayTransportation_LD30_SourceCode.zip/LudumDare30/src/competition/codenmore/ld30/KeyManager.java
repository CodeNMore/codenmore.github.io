package competition.codenmore.ld30;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener{

	public static final int UP = KeyEvent.VK_UP;
	public static final int DOWN = KeyEvent.VK_DOWN;
	public static final int LEFT = KeyEvent.VK_LEFT;
	public static final int RIGHT = KeyEvent.VK_RIGHT;
	public static final int W = KeyEvent.VK_W;
	public static final int A = KeyEvent.VK_A;
	public static final int S = KeyEvent.VK_S;
	public static final int D = KeyEvent.VK_D;
	public static final int R = KeyEvent.VK_R;
	public static final int E = KeyEvent.VK_E;
	public static final int I = KeyEvent.VK_I;
	public static final int B = KeyEvent.VK_B;
	public static final int U = KeyEvent.VK_U;
	public static final int M = KeyEvent.VK_M;
	public static final int N1 = KeyEvent.VK_1;
	public static final int N2 = KeyEvent.VK_2;
	public static final int N3 = KeyEvent.VK_3;
	public static final int N4 = KeyEvent.VK_4;
	public static final int N5 = KeyEvent.VK_5;
	public static final int SPACE = KeyEvent.VK_SPACE;
	
	public boolean[] keys = new boolean[128];
	
	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}

	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}

	public void keyTyped(KeyEvent e) {
		
	}

}
