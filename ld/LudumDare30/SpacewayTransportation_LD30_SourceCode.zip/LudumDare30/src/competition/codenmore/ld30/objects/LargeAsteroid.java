package competition.codenmore.ld30.objects;

import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.states.GameState;

public class LargeAsteroid extends GameObject{

	private boolean active = true;
	
	public LargeAsteroid(float x, float y) {
		super(TextureManager.asteroid2, x, y, TextureManager.asteroid2.width, TextureManager.asteroid2.height);
	}

	public void tick() {
		move();
		if(active && checkCollision(GameState.getPlayer().getBounds())){//Player dead
			GameState.getPlayer().hit(-3);
			active = false;
		}
	}

	public void render(Screen screen) {
		screen.render(texture, (int) x, (int) y);
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
}
