package competition.codenmore.ld30;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

import competition.codenmore.ld30.gfx.Colors;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.SpriteSheet;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.states.CampaignState;
import competition.codenmore.ld30.states.CompletedState;
import competition.codenmore.ld30.states.DeadStateCampaign;
import competition.codenmore.ld30.states.DeadStateEndless;
import competition.codenmore.ld30.states.EndlessState;
import competition.codenmore.ld30.states.InfoState;
import competition.codenmore.ld30.states.MapState;
import competition.codenmore.ld30.states.MenuState;
import competition.codenmore.ld30.states.State;
import competition.codenmore.ld30.states.StoryState;
import competition.codenmore.ld30.util.FileUtils;

public class Game extends Canvas implements Runnable{

	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 350, HEIGHT = 450;
	public static final Dimension SDIM = new Dimension(WIDTH, HEIGHT);
	public static final String TITLE = "Spaceway Transportation";
	private boolean running = false;
	private Thread thread;
	private static JFrame frame;
	private static Game game;
	
	//Rendering
	private BufferStrategy bs;
	private Graphics g;
	private Screen screen;
	
	//Other
	private static KeyManager keyManager;
	private static MouseManager mouseManager;
	
	//States
	public static State gameState;
	public static State menuState;
	public static State deadStateCampaign;
	public static State deadStateEndless;
	public static State infoState;
	public static State campaignState;
	public static State endlessState;
	public static State mapState;
	public static State storyState;
	public static State completedState;
	
	public Game(){
		//Rendering stuff
		screen = new Screen(WIDTH, HEIGHT);
		TextureManager.init(new SpriteSheet(FileUtils.loadAsImage("/spritesheet.png")));
		
		//Other
		keyManager = new KeyManager();
		this.addKeyListener(keyManager);
		mouseManager = new MouseManager();
		this.addMouseListener(mouseManager);
		
		//States
		menuState = new MenuState();
		deadStateCampaign = new DeadStateCampaign();
		deadStateEndless = new DeadStateEndless();
		infoState = new InfoState();
		campaignState = new CampaignState();
		endlessState = new EndlessState();
		mapState = new MapState();
		storyState = new StoryState();
		completedState = new CompletedState();
		State.setState(menuState);
	}
	
	private void tick(){
		if(State.getState() != null)
			State.getState().tick();
	}
	
	private void render(){
		//Init
		bs = this.getBufferStrategy();
		if(bs == null){
			this.createBufferStrategy(2);
			return;
		}
		//Clear
		screen.clear(Colors.BLACK);
		//RENDER
		
		if(State.getState() != null)
			State.getState().render(screen);
		
		//END RENDER
		g = bs.getDrawGraphics();
		g.drawImage(screen.screenImage, 0, 0, WIDTH, HEIGHT, null);
		//Disposal
		bs.show();
		g.dispose();
	}
	
	public void run(){
		double ns = 1000000000 / 60D;
		double delta = 0;
		long now;
		long lastTime = System.nanoTime();
//		long timer = 0;
//		int ticks = 0;
//		int frames = 0;
		
		while(running){
			now = System.nanoTime();
			delta += (now - lastTime) / ns;
//			timer += now - lastTime;
			lastTime = now;
			
			if(delta >= 1){
				tick();
//				ticks++;
				delta--;
			}
			
			render();
//			frames++;
			try {
				Thread.sleep(3);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
//			if(timer >= 1000000000){
////				frame.setTitle("Ticks: " + ticks + " Frames: " + frames);
//				System.out.println(ticks + "   " + frames);
//				ticks = 0;
//				frames = 0;
//				timer = 0;
//			}
		}
		
		stop();
	}
	
	public static void main(String[] args){
		game = new Game();
		game.setPreferredSize(SDIM);
		game.setMaximumSize(SDIM);
		game.setMinimumSize(SDIM);
		
		frame = new JFrame(TITLE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(SDIM);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.add(game);
		frame.pack();
		frame.setVisible(true);
		frame.setAlwaysOnTop(true);
		
		game.start();
	}
	
	public static KeyManager getKeyManager(){
		return keyManager;
	}
	
	public static MouseManager getMouseManager(){
		return mouseManager;
	}
	
	public void start(){
		if(running)
			return;
		running = true;
		thread = new Thread(this, "CodeNMore_CWorlds");
		thread.start();
	}
	
	public void stop(){
		if(!running)
			return;
		running = false;
	}
	
}
