package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.gfx.Colors;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class UI {

	private Player player;
	private int life, maxLife, heat, overHeat;
	private static final int barWidth = Game.WIDTH / 2 - 20, barHeight = TextureManager.ui[0].height - 2;
	private Image hullImage, heatImage, preBar;
	
	public UI(Player player){
		this.player = player;
		hullImage = new Image(barWidth, barHeight);
		heatImage = new Image(barWidth, barHeight);
		preBar = new Image(barWidth, barHeight);
		preBar.clear(Colors.WHITE);
	}
	
	public void tick(){
		if(player.isOnEndless()){
			life = player.getHealth();
			maxLife = Player.startHealth;
			heat = player.getHeat();
			overHeat = player.getOverheat();
		}else{
			life = player.getHealth() - player.getAddedHealth();
			maxLife = Player.startHealth + player.getAddedHealth();
			heat = player.getHeat();
			overHeat = player.getOverheat() + player.getAddedOverheat();
		}
		
		hullImage = new Image((barWidth / maxLife) * life, barHeight);
		hullImage.clear(Colors.LIGHT);
		
		heatImage = new Image((barWidth / overHeat) * heat, barHeight);
		heatImage.clear(Colors.LIGHT);
	}
	
	public void render(Screen screen){
		Font.renderStringSmall(screen, "Hull Damage     Gun Overheat", 5, Game.HEIGHT - 35);
		screen.render(preBar, 9, Game.HEIGHT - 20);
		screen.render(preBar, barWidth + 30, Game.HEIGHT - 20);
		screen.render(hullImage, 10, Game.HEIGHT - 20);
		screen.render(heatImage, barWidth + 30, Game.HEIGHT - 20);
	}
	
}
