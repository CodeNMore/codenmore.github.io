package competition.codenmore.ld30.sfx;

import java.applet.Applet;
import java.applet.AudioClip;

public class SoundManager {

	//SOUND STUFF
	
	public static AudioClip shot = instance().loadAudioClip("/shot.wav");
	public static AudioClip hit = instance().loadAudioClip("/hit.wav");
	public static AudioClip purchase = instance().loadAudioClip("/purchase.wav");
	public static AudioClip boom = instance().loadAudioClip("/boom.wav");
	public static AudioClip select = instance().loadAudioClip("/select.wav");
	public static AudioClip dud = instance().loadAudioClip("/dud.wav");
	
	//MEHTOD
	public AudioClip loadAudioClip(String path){
		return Applet.newAudioClip(getClass().getResource(path));
	}
	
	//OTHER
	private volatile static SoundManager instance;
	
	public static SoundManager instance(){
		if(instance == null)
			instance = new SoundManager();
		return instance;
	}
	
}
