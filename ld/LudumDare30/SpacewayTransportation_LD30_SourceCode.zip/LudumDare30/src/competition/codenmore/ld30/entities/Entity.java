package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.objects.GameObject;
import competition.codenmore.ld30.sfx.SoundManager;

public abstract class Entity extends GameObject{

	protected int health;
	
	public Entity(Image texture, float x, float y, int width, int height, int health){
		super(texture, x, y, width, height);
		this.health = health;
	}
	
	public void hit(int amount){
		SoundManager.hit.play();
		health += amount;
		if(health <= 0)
			die();
	}
	
	public void setHealth(int health){
		this.health = health;
	}
	
	public int getHealth(){
		return health;
	}
	
	public void die(){
		
	}
	
}
