package competition.codenmore.ld30.objects;

import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.states.GameState;

public class Asteroid extends GameObject{

	private boolean active = true;
	
	public Asteroid(float x, float y) {
		super(TextureManager.asteroid1, x, y, TextureManager.asteroid1.width, TextureManager.asteroid1.height);
	}

	public void tick() {
		move();
		if(active && checkCollision(GameState.getPlayer().getBounds())){//Player dead
			GameState.getPlayer().hit(-2);
			active = false;
		}
	}

	public void render(Screen screen) {
		screen.render(texture, (int) x, (int) y);
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
