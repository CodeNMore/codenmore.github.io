package competition.codenmore.ld30.gfx;

import competition.codenmore.ld30.Game;

public class Background {

	private Image i1, i2;
	private float speed, y1, y2;
	
	public Background(Image i1, Image i2, float speed){
		this.i1 = i1;
		this.i2 = i2;
		this.speed = speed;
		y1 = 0;
		y2 = -i2.height;
	}
	
	public void tick(){
		y1 += speed;
		y2 += speed;
		if(y1 > Game.HEIGHT)
			y1 = y2 - i1.height;
		if(y2 > Game.HEIGHT)
			y2 = y1 - i2.height;
	}
	
	public void render(Screen screen){
		screen.render(i1, 0, (int) y1);
		screen.render(i2, 0, (int) y2);
	}
	
}
