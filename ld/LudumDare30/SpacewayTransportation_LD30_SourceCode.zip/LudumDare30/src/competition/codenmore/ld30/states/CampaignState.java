package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.level.Level;
import competition.codenmore.ld30.map.Planet;
import competition.codenmore.ld30.util.Timer;

public class CampaignState extends GameState{

	private Timer timer, distanceTimer;
	private int travelingDistance;
	
	private static final int STARTPOINTER = 4;
	private int delayTime = 250;
	private static final int duration = 0;
	private int nextSwitch, setPointer;
	private boolean atEnd;

	private int[] sets = {
			800, 1100, 3, 8000,
			700, 1000, 6, 10000,
			600, 875, 10, 30000,
			525, 775, 10, 30000,
			450, 625, 30, 0
	};
	
	public CampaignState(){
		super();
		timer = new Timer(false);
		distanceTimer = new Timer(false);
	}
	
	public void tick(){
		super.tick();
		distanceTimer.update();
		timer.update();
		if(distanceTimer.getTimer() >= Planet.distanceToTime(travelingDistance)){
			//DONE LEVEL
			level.stop();
			GameState.getPlayer().addCurrency(travelingDistance * GameState.getPlayer().getPassengers() * 2);
			((CompletedState) Game.completedState).setPartsEarned(travelingDistance * GameState.getPlayer().getPassengers() * 2);
			((CompletedState) Game.completedState).setArrivalName(MapState.getMap().getPlanets()[MapState.getMap().getSelected()].getName());
			((CompletedState) Game.completedState).setDepartedName(MapState.getMap().getPlanets()[MapState.getMap().getLocation()].getName());
			MapState.getMap().setLocation(MapState.getMap().getSelected());
			State.setState(Game.completedState);
		}else{
			if(!atEnd && timer.getTimer() >= nextSwitch){
				level.start(sets[setPointer++], sets[setPointer++], delayTime, duration, sets[setPointer++], false);
				nextSwitch = sets[setPointer++];
				
				if(setPointer >= sets.length)
					atEnd = true;
				
				timer.reset();
			}
		}
	}
	
	public void render(Screen screen){
		super.render(screen);
		Font.renderStringSmall(screen, "Traveled " + distanceTimer.getTimerInt() + " of " + Planet.distanceToTime(travelingDistance), 5, 5);
	}
	
	protected void levelSet() {
		setPointer = STARTPOINTER;
		atEnd = false;
		
		level = new Level();
		level.setMinSpeed(4);
		level.setMaxSpeed(7);
		level.setEnemyGenRand(76);
		level.setEnemyGenModulus(4);
		level.start(sets[0], sets[1], delayTime, duration, sets[2], false);
		nextSwitch = sets[3];
		
		timer.reset();
		distanceTimer.reset();
	}
	
	public void onShow(){
		super.onShow();
		player.setOnEndless(false);
	}
	
	public int getTravelingDistance() {
		return travelingDistance;
	}

	public void setTravelingDistance(int travelingDistance) {
		this.travelingDistance = travelingDistance;
	}
	
}
