package competition.codenmore.ld30.entities;

import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;
import competition.codenmore.ld30.states.GameState;

public class BasicEnemy extends Enemy {

	public static int START_HEALTH;
	private boolean active = true;
	
	public BasicEnemy(float x, float y, int startHealth) {
		super(TextureManager.enemy1, x, y, startHealth, 2.25f);
		START_HEALTH = startHealth;
	}

	public void tick() {
		followPlayerX();
		ys = speed;
		move();
		
		if(active && GameState.getPlayer().getBounds().intersects(getBounds())){
			GameState.getPlayer().hit(-1);
			active = false;
		}
	}

	public void render(Screen screen) {
		screen.render(texture, (int) x, (int) y);
	}
	
	public void reset(){
		health = START_HEALTH;
		active = true;
	}

}
