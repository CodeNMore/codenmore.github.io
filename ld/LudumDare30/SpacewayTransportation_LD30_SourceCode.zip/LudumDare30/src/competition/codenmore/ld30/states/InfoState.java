package competition.codenmore.ld30.states;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.KeyManager;
import competition.codenmore.ld30.gfx.Background;
import competition.codenmore.ld30.gfx.Font;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.gfx.TextureManager;

public class InfoState extends State{

	private static Background bg;
	
	public InfoState(){
		bg = new Background(TextureManager.background, TextureManager.background, 0.25f);
	}

	public void tick() {
		input();
		bg.tick();
	}

	public void render(Screen screen) {
		bg.render(screen);
		Font.renderStringLarge(screen, "Info", 134, 20);
		Font.renderStringLarge(screen, "Made for Ludum", 10, 80);
		Font.renderStringLarge(screen, "Dare 30 in 48", 10, 120);
		Font.renderStringLarge(screen, "hours by", 80, 160);
		Font.renderStringLarge(screen, "CodeNMore!", 60, 200);
		Font.renderStringLarge(screen, "Visit me on", 40, 240);
		Font.renderStringLarge(screen, "youtube", 90, 280);
		Font.renderStringLarge(screen, "<B> Back", 80, 400);
	}
	
	private void input(){
		if(Game.getKeyManager().keys[KeyManager.B])
			State.setState(Game.menuState);
	}

	public void onShow() {
		
	}

	public void onHide() {
		
	}
	
}
