package competition.codenmore.ld30.objects;

import java.awt.Rectangle;

import competition.codenmore.ld30.gfx.Image;
import competition.codenmore.ld30.gfx.Screen;

public abstract class GameObject {

	protected Rectangle bounds;
	protected Image texture;
	protected float x, y, xs, ys;
	protected int width, height;
	
	public GameObject(Image texture, float x, float y, int width, int height){
		this.texture = texture;
		this.x = x;
		this.y = y;
		this.xs = 0;
		this.ys = 0;
		this.width = width;
		this.height = height;
		bounds = new Rectangle((int) x, (int) y, width, height);
	}
	
	public void move(){
		x += xs;
		y += ys;
	}
	
	public abstract void tick();
	
	public abstract void render(Screen screen);

	public Rectangle getBounds(){
		bounds.x = (int) x;
		bounds.y = (int) y;
		return bounds;
	}
	
	public boolean checkCollision(Rectangle r){
		if(r.intersects(getBounds()))
			return true;
		return false;
	}
	
	//GETTERS/SETTERS
//	public Image[] getTexture() {
//		return texture;
//	}
//
//	public void setTexture(Image[] texture) {
//		this.texture = texture;
//	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getXs() {
		return xs;
	}

	public void setXs(float xs) {
		this.xs = xs;
	}

	public float getYs() {
		return ys;
	}

	public void setYs(float ys) {
		this.ys = ys;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
		bounds.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
		bounds.height = height;
	}
	
}
