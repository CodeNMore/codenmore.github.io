package competition.codenmore.ld30.entities;

public class Parts {

	public static int maxDistanceCost = 10, healthCost = 15, passengerCost = 15, overheatCost = 10;
	
	public static void addMaxDistanceCost(int amt){
		maxDistanceCost += amt;
	}
	
	public static void addPassengerCost(int amt){
		passengerCost += amt;
	}
	
	public static void addOverheatCost(int amt){
		overheatCost += amt;
	}
	
	public static void addHealthCost(int amt){
		healthCost += amt;
	}

	public static int getMaxDistanceCost() {
		return maxDistanceCost;
	}

	public static void setMaxDistanceCost(int maxDistanceCost) {
		Parts.maxDistanceCost = maxDistanceCost;
	}

	public static int getHealthCost() {
		return healthCost;
	}

	public static void setHealthCost(int healthCost) {
		Parts.healthCost = healthCost;
	}

	public static int getPassengerCost() {
		return passengerCost;
	}

	public static void setPassengerCost(int passengerCost) {
		Parts.passengerCost = passengerCost;
	}

	public static int getOverheatCost() {
		return overheatCost;
	}

	public static void setOverheatCost(int overheatCost) {
		Parts.overheatCost = overheatCost;
	}
	
}
