package competition.codenmore.ld30.level;

import java.util.ArrayList;
import java.util.Random;

import competition.codenmore.ld30.Game;
import competition.codenmore.ld30.entities.BasicEnemy;
import competition.codenmore.ld30.entities.BasicShootingEnemy;
import competition.codenmore.ld30.entities.Enemy;
import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.objects.Asteroid;
import competition.codenmore.ld30.objects.GameObject;
import competition.codenmore.ld30.objects.LargeAsteroid;
import competition.codenmore.ld30.objects.Projectile;
import competition.codenmore.ld30.states.GameState;
import competition.codenmore.ld30.util.Timer;

public class Level {

	private static final int HIDE = Game.WIDTH;

	private boolean running = false, enemyPending = false, doPauseForEnemy = false;
	private Random random;
	private Timer timer, durationTimer;
	private int minInterval, maxInterval, intervalsToGenerate, generatedIntervals, nextInterval, levelDuration, enemiesToAdd, addedEnemies;
	private GameObject tempObject;
	private int tempIndex;
	private Projectile tempProjectile;

	// User-settable depending variables
	private int maxSpeed = 3, minSpeed = 1, enemyGenRand = 101, enemyGenModulus = 5;

	private ArrayList<Enemy> enemies;
	private ArrayList<GameObject> objectsToRender, objectsAvailable;
	private ArrayList<Projectile> projectiles;

	public Level() {
		timer = new Timer(false);
		durationTimer = new Timer(false);
		random = new Random();

		objectsAvailable = new ArrayList<GameObject>();
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new Asteroid(HIDE, 0));
		objectsAvailable.add(new LargeAsteroid(HIDE, 0));
		objectsAvailable.add(new LargeAsteroid(HIDE, 0));

		enemies = new ArrayList<Enemy>();
		enemies.add(new BasicEnemy(HIDE, 0, 3));
		enemies.add(new BasicEnemy(HIDE, 0, 4));
		enemies.add(new BasicEnemy(HIDE, 0, 2));
		enemies.add(new BasicShootingEnemy(HIDE, 0, 3));
		enemies.add(new BasicShootingEnemy(HIDE, 0, 2));

		objectsToRender = new ArrayList<GameObject>();

		projectiles = new ArrayList<Projectile>();
	}

	public void tick() {
		if (running) {
			if (!enemyPending) {
				timer.update();
				durationTimer.update();
			}

			if (levelDuration != 0 && durationTimer.getTimer() >= levelDuration) {
				intervalsToGenerate = 1;
				generatedIntervals = 2;
			}

			if (timer.getTimer() >= nextInterval) {
				// RESET AND GENERATE NEW INTERVAL
				timer.reset();
				nextInterval = random.nextInt(maxInterval - minInterval + 1)
						+ minInterval;
				generatedIntervals++;
				// Check if end of level
				if (intervalsToGenerate != 0
						&& generatedIntervals > intervalsToGenerate) {
					// Wait until level is fully completed
					if (objectsToRender.size() <= 0) {
						stop();
						return;
					}
				} else {
					// SEND NEW OBJECT
					if (addedEnemies < enemiesToAdd
							&& enemies.size() != 0
							& random.nextInt(enemyGenRand) % enemyGenModulus == 0) {
						// Enemy generate
						addedEnemies++;
						if (doPauseForEnemy)
							enemyPending = true;
						tempIndex = random.nextInt(enemies.size());
						tempObject = enemies.get(tempIndex);
						enemies.remove(tempIndex);
						// Set
						tempObject.setY(-tempObject.getHeight());
						tempObject.setX(random.nextInt(Game.WIDTH
								- tempObject.getWidth()));

						objectsToRender.add(tempObject);
					} else {
						if (objectsAvailable.size() != 0) {
							tempIndex = random.nextInt(objectsAvailable.size());
							tempObject = objectsAvailable.get(tempIndex);
							objectsAvailable.remove(tempIndex);
							// Set
							tempObject.setY(-tempObject.getHeight());
							tempObject.setX(random.nextInt(Game.WIDTH
									- tempObject.getWidth()));
							tempObject.setYs(random.nextInt(maxSpeed - minSpeed
									+ 1)
									+ minSpeed);

							objectsToRender.add(tempObject);
						}
					}
				}
			}

			// NOW "TICK"/MOVE ALL OBJECTS TO RENDER, CHECK IF CURRENTLY USED
			for (tempIndex = 0; tempIndex < objectsToRender.size(); tempIndex++) {
				tempObject = objectsToRender.get(tempIndex);
				tempObject.tick();// Will move object & check collision with
										// player
				// OBJECT DONE, RE-USABLE NOW
				if (tempObject instanceof Enemy
						&& (((Enemy) tempObject).getHealth() <= 0 || tempObject
								.getY() > Game.HEIGHT)) {
					objectsToRender.remove(tempIndex);
					tempObject.setX(HIDE);
					tempObject.setY(0);
					if(((Enemy) tempObject).getHealth() <= 0)
						GameState.getPlayer().addKill(1);
					((Enemy) tempObject).reset();
					enemies.add(((Enemy) tempObject));
					enemyPending = false;
				} else if (tempObject.getY() > Game.HEIGHT) {
					objectsToRender.remove(tempIndex);
					tempObject.setX(HIDE);
					tempObject.setY(0);
					
					if(tempObject instanceof Asteroid)
						((Asteroid) tempObject).setActive(true);
					else if(tempObject instanceof LargeAsteroid)
						((LargeAsteroid) tempObject).setActive(true);
					
					objectsAvailable.add(tempObject);
				}
			}

			for (tempIndex = 0; tempIndex < projectiles.size(); tempIndex++) {
				if (tempIndex < projectiles.size()) {//TODO: HERE ADDED
					tempProjectile = projectiles.get(tempIndex);
					if (tempProjectile.tick()) {
						if(tempIndex < projectiles.size()){
							try{
								projectiles.remove(tempIndex);
							}catch(Exception e){
								e.printStackTrace();
								System.err.println("ERROR PROJECTILE, AGIAN");
								break;
							}
						}
					} else {
						for (GameObject o : objectsToRender)
							if (o instanceof Enemy
									&& o.getBounds().intersects(
											tempProjectile.getBounds())
									&& tempProjectile.isPlayerProjectile()) {
								projectiles.remove(tempIndex);
								((Enemy) o).hit(-1);
							} else if (o.getBounds().intersects(
									tempProjectile.getBounds())) {
								if(tempIndex < projectiles.size())
									projectiles.remove(tempIndex);
							}
					}
				}
			}
		}
	}

	public void render(Screen screen) {
		if (running) {
			// RENDER ALL OBJECTS TO RENDER
			for (GameObject o : objectsToRender)
				o.render(screen);

			for (Projectile p : projectiles)
				p.render(screen);
		}
	}

	public void start(int minInterval, int maxInterval, int startingInterval, int levelDuration, int enemiesToAdd, boolean doPauseForEnemy) {
		this.minInterval = minInterval;
		this.maxInterval = maxInterval;
		this.intervalsToGenerate = 0;
		this.nextInterval = startingInterval;
		this.levelDuration = levelDuration;
		this.enemiesToAdd = enemiesToAdd;
		this.doPauseForEnemy = doPauseForEnemy;
		addedEnemies = 0;
		generatedIntervals = 0;
		
		durationTimer.reset();
		timer.reset();
		
		enemyPending = false;

		running = true;
	}

	public void stop() {
		running = false;
		
		for (tempIndex = 0; tempIndex < objectsToRender.size(); tempIndex++) {
			tempObject = objectsToRender.get(tempIndex);
			objectsToRender.remove(tempIndex);
			tempObject.setX(HIDE);
			tempObject.setY(0);
			if (tempObject instanceof Enemy){
				enemies.add((Enemy) tempObject);
			}
			else{
				objectsAvailable.add(tempObject);
			}
		}
		
		projectiles.clear();
	}

	public ArrayList<Projectile> getProjectiles() {
		return projectiles;
	}

	public boolean getRunning() {
		return running;
	}

	public int getMinInterval() {
		return minInterval;
	}

	public void setMinInterval(int minInterval) {
		this.minInterval = minInterval;
	}

	public int getMaxInterval() {
		return maxInterval;
	}

	public void setMaxInterval(int maxInterval) {
		this.maxInterval = maxInterval;
	}

	public int getIntervalsToGenerate() {
		return intervalsToGenerate;
	}

	public void setIntervalsToGenerate(int intervalsToGenerate) {
		this.intervalsToGenerate = intervalsToGenerate;
	}

	public int getNextInterval() {
		return nextInterval;
	}

	public void setNextInterval(int nextInterval) {
		this.nextInterval = nextInterval;
	}

	public float getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public int getMinSpeed() {
		return minSpeed;
	}

	public void setMinSpeed(int minSpeed) {
		this.minSpeed = minSpeed;
	}

	public int getEnemyGenRand() {
		return enemyGenRand;
	}

	public void setEnemyGenRand(int enemyGenRand) {
		this.enemyGenRand = enemyGenRand;
	}

	public int getEnemyGenModulus() {
		return enemyGenModulus;
	}

	public void setEnemyGenModulus(int enemyGenModulus) {
		this.enemyGenModulus = enemyGenModulus;
	}

	// public void tick(){
	// if(running){
	// timer.update();
	//
	// if(timer.getTimer() >= nextInterval){
	// //RESET AND GENERATE NEW INTERVAL
	// timer.reset();
	// nextInterval = random.nextInt(maxInterval - minInterval + 1) +
	// minInterval;
	// generatedIntervals++;
	// //Check if end of level
	// if(generatedIntervals > intervalsToGenerate){
	// //Wait until level is fully completed
	// if(objectsToRender.size() <= 0){
	// stop();
	// return;
	// }
	// }else{
	// //SEND NEW OBJECT
	// tempIndex = random.nextInt(objects.length);
	// tempObject = objects[tempIndex];
	// //Check if object is available
	// if(!tempObject.isCurrentlyUsed()){
	// tempObject.setCurrentlyUsed(true);
	// tempObject.setY(-tempObject.getHeight());
	// tempObject.setX(random.nextInt(Game.WIDTH - tempObject.getWidth()));
	// tempObject.setYs(random.nextFloat() * speedMultiplier);
	//
	// objectsToRender.add(tempObject);
	// }
	// }
	// }
	//
	// //NOW "TICK"/MOVE ALL OBJECTS TO RENDER, CHECK IF CURRENTLY USED
	// for(tempIndex = 0;tempIndex < objectsToRender.size();tempIndex++){
	// tempObject = objectsToRender.get(tempIndex);
	// tempObject.tick();//Will move object & check collision with player
	// //OBJECT DONE, RE-USABLE NOW
	// if(tempObject.getY() > Game.HEIGHT){
	// objectsToRender.remove(tempIndex);
	// tempObject.setCurrentlyUsed(false);
	// tempObject.setX(HIDE);
	// tempObject.setY(0);
	// }
	// }
	//
	// }
	// }

}
