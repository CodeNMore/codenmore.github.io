package competition.codenmore.ld30.states;

import competition.codenmore.ld30.gfx.Screen;
import competition.codenmore.ld30.sfx.SoundManager;

public abstract class State {

	private static State state;
	
	public static State getState(){
		return state;
	}
	
	public static void setState(State state){
		if(State.state != null)
			State.state.onHide();
		State.state = state;
		if(State.state != null)
			State.state.onShow();
		
		SoundManager.select.play();
	}
	
	/////////////////////////////////////////
	
	public abstract void tick();
	
	public abstract void render(Screen screen);
	
	public abstract void onShow();
	
	public abstract void onHide();
	
}
