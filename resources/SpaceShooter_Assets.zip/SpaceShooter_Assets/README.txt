Main artwork created by Kenney, under the CC0 license:
https://opengameart.org/content/space-shooter-art

Power-up icons created by Cethiel, under the CC0 license:
https://opengameart.org/content/pickup-items-icons